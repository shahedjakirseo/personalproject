import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Books from './pages/Books';
import Users from './pages/Users';
import Products from './pages/Products';
import Blogs from './pages/Blogs';
import Courses from './pages/Courses';
import CourseChapters from './pages/CourseChapters';
import ChapterLessons from './pages/ChapterLessons';
import AddLesson from './pages/AddLesson';
import EditLesson from './pages/EditLesson';
import Orders from './pages/Orders';
import Coupons from './pages/Coupons';
import Invoices from './pages/Invoices';
import Layout from './components/Layout';
import { AuthProvider, useAuth } from './contexts/AuthContext';

const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="min-h-screen bg-[#EEF0F4] flex items-center justify-center">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
    </div>;
  }

  return user ? <Layout>{children}</Layout> : <Navigate to="/login" />;
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            }
          />
          <Route
            path="/books"
            element={
              <PrivateRoute>
                <Books />
              </PrivateRoute>
            }
          />
          <Route
            path="/users"
            element={
              <PrivateRoute>
                <Users />
              </PrivateRoute>
            }
          />
          <Route
            path="/products"
            element={
              <PrivateRoute>
                <Products />
              </PrivateRoute>
            }
          />
          <Route
            path="/blogs"
            element={
              <PrivateRoute>
                <Blogs />
              </PrivateRoute>
            }
          />
          <Route
            path="/courses"
            element={
              <PrivateRoute>
                <Courses />
              </PrivateRoute>
            }
          />
          <Route
            path="/courses/:courseId/chapters"
            element={
              <PrivateRoute>
                <CourseChapters />
              </PrivateRoute>
            }
          />
          <Route
            path="/courses/:courseId/chapters/:chapterId/lessons"
            element={
              <PrivateRoute>
                <ChapterLessons />
              </PrivateRoute>
            }
          />
          <Route
            path="/courses/:courseId/chapters/:chapterId/lessons/add"
            element={
              <PrivateRoute>
                <AddLesson />
              </PrivateRoute>
            }
          />
          <Route
            path="/courses/:courseId/chapters/:chapterId/lessons/:lessonId/edit"
            element={
              <PrivateRoute>
                <EditLesson />
              </PrivateRoute>
            }
          />
          <Route
            path="/orders"
            element={
              <PrivateRoute>
                <Orders />
              </PrivateRoute>
            }
          />
          <Route
            path="/coupons"
            element={
              <PrivateRoute>
                <Coupons />
              </PrivateRoute>
            }
          />
          <Route
            path="/invoices"
            element={
              <PrivateRoute>
                <Invoices />
              </PrivateRoute>
            }
          />
        </Routes>
        <Toaster position="top-right" />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;