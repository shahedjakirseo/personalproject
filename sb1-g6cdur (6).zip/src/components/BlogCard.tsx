import React from 'react';
import { format } from 'date-fns';
import { Edit2, Trash2, Tag, Star, Clock, Eye } from 'lucide-react';
import { BlogCardProps } from '../types/blog';

export default function BlogCard({ 
  blog, onEdit, onDelete, onToggleStatus, onToggleFeatured 
}: BlogCardProps) {
  return (
    <div className="neu-flat p-6 space-y-4">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-gray-900">{blog.title}</h3>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Clock className="w-4 h-4" />
            {blog.readTime} min read
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={onToggleFeatured}
            className={`neu-button p-2 ${blog.featured ? 'text-yellow-600' : 'text-gray-400'}`}
            title={blog.featured ? 'Remove from featured' : 'Mark as featured'}
          >
            <Star className="w-4 h-4" />
          </button>
          <button
            onClick={onEdit}
            className="neu-button p-2 text-blue-600"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={onDelete}
            className="neu-button p-2 text-red-600"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {blog.coverImage && (
        <img
          src={blog.coverImage}
          alt={blog.title}
          className="w-full h-48 object-cover rounded-lg shadow-md"
        />
      )}

      <div className="flex flex-wrap gap-2">
        {blog.category && (
          <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-gray-600">
            <Tag className="w-3 h-3" />
            {blog.category.name}
          </div>
        )}
        <button
          onClick={onToggleStatus}
          className={`neu-button px-3 py-1 text-sm flex items-center gap-1
            ${blog.status === 'published' ? 'text-green-600' : 'text-orange-600'}`}
        >
          <Eye className="w-3 h-3" />
          {blog.status.charAt(0).toUpperCase() + blog.status.slice(1)}
        </button>
      </div>

      <p className="text-gray-600 line-clamp-3">{blog.excerpt}</p>

      <div className="flex items-center justify-between text-sm text-gray-500">
        <div className="flex items-center gap-2">
          <img
            src={blog.author.avatar}
            alt={blog.author.name}
            className="w-6 h-6 rounded-full"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.onerror = null;
              target.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(blog.author.name);
            }}
          />
          <span>{blog.author.name}</span>
        </div>
        <div>
          {blog.publishDate
            ? format(blog.publishDate, 'MMM dd, yyyy')
            : 'Not published'}
        </div>
      </div>
    </div>
  );
}