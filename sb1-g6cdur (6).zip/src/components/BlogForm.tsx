import React, { useState, useRef } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Blog, BlogFormData } from '../types/blog';
import CategorySelect from './CategorySelect';
import FileUpload from './FileUpload';
import { useAuth } from '../contexts/AuthContext';

interface BlogFormProps {
  onSubmit: (data: BlogFormData) => Promise<void>;
  initialData?: Blog;
  onCancel: () => void;
}

const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['blockquote', 'code-block'],
    [{ align: [] }],
    [{ color: [] }, { background: [] }],
    ['link', 'image', 'video'],
    ['clean']
  ]
};

const formats = [
  'header',
  'bold', 'italic', 'underline', 'strike',
  'list', 'bullet',
  'blockquote', 'code-block',
  'align',
  'color', 'background',
  'link', 'image', 'video'
];

export default function BlogForm({ onSubmit, initialData, onCancel }: BlogFormProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState<BlogFormData>({
    title: initialData?.title || '',
    content: initialData?.content || '',
    excerpt: initialData?.excerpt || '',
    coverImage: initialData?.coverImage || '',
    category: initialData?.category || null,
    tags: initialData?.tags || [],
    status: initialData?.status || 'draft',
    publishDate: initialData?.publishDate ? format(initialData.publishDate, 'yyyy-MM-dd') : null,
    featured: initialData?.featured || false,
    seo: initialData?.seo || {
      metaTitle: '',
      metaDescription: '',
      keywords: []
    }
  });
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [tagInput, setTagInput] = useState('');
  const quillRef = useRef<ReactQuill>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit({
        ...formData,
        author: {
          name: user?.displayName || 'Anonymous',
          avatar: user?.photoURL || ''
        }
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Rest of the form remains the same */}
      <div className="neu-flat p-2">
        <ReactQuill
          ref={quillRef}
          theme="snow"
          value={formData.content}
          onChange={content => setFormData(prev => ({ ...prev, content }))}
          modules={modules}
          formats={formats}
        />
      </div>
      {/* Rest of the form remains the same */}
    </form>
  );
}