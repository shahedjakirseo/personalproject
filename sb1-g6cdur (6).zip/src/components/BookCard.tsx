import React, { useState } from 'react';
import { Edit2, Trash2, ChevronDown, ChevronUp, Tag, FileText } from 'lucide-react';
import { Book } from '../types/book';
import sanitizeHtml from 'sanitize-html';

interface BookCardProps {
  book: Book;
  onEdit: () => void;
  onDelete: () => void;
}

const sanitizeOptions = {
  allowedTags: [
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'blockquote', 'p', 'a', 'ul', 'ol', 'nl', 'li',
    'b', 'i', 'strong', 'em', 'strike', 'code', 'hr', 'br', 'div',
    'table', 'thead', 'caption', 'tbody', 'tr', 'th', 'td', 'pre'
  ],
  allowedAttributes: {
    'a': ['href', 'name', 'target'],
    '*': ['class']
  }
};

const formatDate = (date: any) => {
  if (!date) return 'Unknown date';
  
  if (date && typeof date.toDate === 'function') {
    return date.toDate().toLocaleDateString();
  }
  
  if (date instanceof Date) {
    return date.toLocaleDateString();
  }
  
  if (typeof date === 'string') {
    return new Date(date).toLocaleDateString();
  }
  
  return 'Invalid date';
};

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};

export default function BookCard({ book, onEdit, onDelete }: BookCardProps) {
  const [expanded, setExpanded] = useState(false);
  const sanitizedSummary = sanitizeHtml(book.longSummary || '', sanitizeOptions);
  
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = sanitizedSummary;
  const textContent = tempDiv.textContent || '';
  
  const truncatedText = textContent.length > 300 
    ? textContent.substr(0, 300).split(' ').slice(0, -1).join(' ') + '...'
    : textContent;

  return (
    <div className="neu-flat p-6 space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">{book.bookName}</h3>
          {book.authorName && <p className="text-gray-600">{book.authorName}</p>}
        </div>
        <div className="flex gap-2">
          <button
            onClick={onEdit}
            className="neu-button p-2 text-blue-600"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={onDelete}
            className="neu-button p-2 text-red-600"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-2">
        {book.category && (
          <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-gray-600">
            <Tag className="w-3 h-3" />
            {book.category.name}
          </div>
        )}
        {book.price > 0 && (
          <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-green-600">
            {formatPrice(book.price)}
          </div>
        )}
      </div>

      {book.coverImageURL && (
        <img
          src={book.coverImageURL}
          alt={book.bookName}
          className="w-full h-48 object-cover rounded-lg shadow-md"
        />
      )}

      {book.longSummary && (
        <div className="space-y-2">
          <div 
            className="prose prose-sm max-w-none text-gray-700"
            dangerouslySetInnerHTML={{ 
              __html: expanded ? sanitizedSummary : `<p>${truncatedText}</p>`
            }}
          />
          {textContent.length > 300 && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="neu-button px-3 py-1 text-sm text-blue-600 flex items-center gap-1"
            >
              {expanded ? (
                <>
                  Show Less <ChevronUp className="w-4 h-4" />
                </>
              ) : (
                <>
                  Read More <ChevronDown className="w-4 h-4" />
                </>
              )}
            </button>
          )}
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {book.audioURL && (
          <audio controls className="w-full mb-2">
            <source src={book.audioURL} type="audio/mpeg" />
            Your browser does not support the audio element.
          </audio>
        )}
        
        {book.pdfURL && (
          <a
            href={book.pdfURL}
            target="_blank"
            rel="noopener noreferrer"
            className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-blue-600"
          >
            <FileText className="w-3 h-3" />
            View PDF
          </a>
        )}
      </div>

      <div className="text-sm text-gray-500">
        Added: {formatDate(book.createdAt)}
      </div>
    </div>
  );
}