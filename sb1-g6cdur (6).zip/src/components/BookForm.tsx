import React, { useState, useRef, useCallback } from 'react';
import { PlusCircle, Link, FileText } from 'lucide-react';
import ReactQuill from 'react-quill';
import type { UnprivilegedEditor } from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { BookFormData, Book } from '../types/book';
import CategorySelect from './CategorySelect';

interface BookFormProps {
  onSubmit: (data: BookFormData) => Promise<void>;
  initialData?: Book;
  onCancel: () => void;
}

const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['blockquote', 'code-block'],
    ['link', 'image'],
    ['clean']
  ]
};

const formats = [
  'header',
  'bold', 'italic', 'underline', 'strike',
  'list', 'bullet',
  'blockquote', 'code-block',
  'link', 'image'
];

export default function BookForm({ onSubmit, initialData, onCancel }: BookFormProps) {
  const editorRef = useRef<ReactQuill>(null);
  const [formData, setFormData] = useState<BookFormData>({
    bookName: initialData?.bookName || '',
    authorName: initialData?.authorName || '',
    longSummary: initialData?.longSummary || '',
    audioURL: initialData?.audioURL || '',
    pdfURL: initialData?.pdfURL || '',
    coverImageURL: initialData?.coverImageURL || '',
    category: initialData?.category || null,
    price: initialData?.price || 0
  });

  const handleEditorChange = useCallback((
    content: string,
    _delta: any,
    _source: any,
    editor: UnprivilegedEditor
  ) => {
    setFormData(prev => ({ ...prev, longSummary: content }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Book Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full"
          value={formData.bookName}
          onChange={e => setFormData(prev => ({ ...prev, bookName: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Author Name</label>
        <input
          type="text"
          className="neu-input w-full"
          value={formData.authorName}
          onChange={e => setFormData(prev => ({ ...prev, authorName: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
        <CategorySelect
          selectedCategory={formData.category}
          onChange={category => setFormData(prev => ({ ...prev, category }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Price (BDT)</label>
        <input
          type="number"
          min="0"
          step="1"
          className="neu-input w-full"
          value={formData.price}
          onChange={e => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
          placeholder="Enter price in BDT"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Summary</label>
        <div className="neu-flat p-2">
          <ReactQuill
            ref={editorRef}
            theme="snow"
            value={formData.longSummary}
            onChange={handleEditorChange}
            modules={modules}
            formats={formats}
            preserveWhitespace
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Link className="w-4 h-4" />
            Audio URL
          </div>
        </label>
        <input
          type="url"
          className="neu-input w-full"
          value={formData.audioURL}
          onChange={e => setFormData(prev => ({ ...prev, audioURL: e.target.value }))}
          placeholder="https://firebasestorage.googleapis.com/..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            PDF URL
          </div>
        </label>
        <input
          type="url"
          className="neu-input w-full"
          value={formData.pdfURL}
          onChange={e => setFormData(prev => ({ ...prev, pdfURL: e.target.value }))}
          placeholder="https://firebasestorage.googleapis.com/..."
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <div className="flex items-center gap-2">
            <Link className="w-4 h-4" />
            Cover Image URL
          </div>
        </label>
        <input
          type="url"
          className="neu-input w-full"
          value={formData.coverImageURL}
          onChange={e => setFormData(prev => ({ ...prev, coverImageURL: e.target.value }))}
          placeholder="https://firebasestorage.googleapis.com/..."
        />
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
        >
          <PlusCircle className="w-4 h-4" />
          {initialData ? 'Update' : 'Add'} Book
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}