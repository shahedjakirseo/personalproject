import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { Upload } from 'lucide-react';
import { BlogFormData } from '../types/blog';
import toast from 'react-hot-toast';

interface BulkBlogUploadProps {
  onUpload: (blogs: BlogFormData[], onProgress: (progress: number) => void) => Promise<void>;
  onClose: () => void;
}

export default function BulkBlogUpload({ onUpload, onClose }: BulkBlogUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [currentBlog, setCurrentBlog] = useState('');
  const [processedCount, setProcessedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  const handleProgress = (progress: number) => {
    setUploadProgress(progress);
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setIsUploading(true);
      Papa.parse(file, {
        complete: async (results) => {
          try {
            const blogs = results.data
              .filter((row: any) => row.title && row.content)
              .map((row: any) => ({
                title: row.title,
                content: row.content,
                excerpt: row.excerpt || '',
                coverImage: row.coverImage || '',
                tags: row.tags ? row.tags.split(',').map((tag: string) => tag.trim()) : [],
                status: (row.status === 'published' ? 'published' : 'draft') as 'draft' | 'published',
                publishDate: row.publishDate || null,
                featured: row.featured === 'true',
                categoryName: row.category ? row.category.trim() : null,
                seo: {
                  metaTitle: row.metaTitle || row.title,
                  metaDescription: row.metaDescription || row.excerpt || '',
                  keywords: row.keywords ? row.keywords.split(',').map((k: string) => k.trim()) : []
                }
              }));

            if (blogs.length === 0) {
              toast.error('No valid blog data found in CSV');
              return;
            }

            setTotalCount(blogs.length);
            
            await onUpload(blogs, (progress) => {
              handleProgress(progress);
              setProcessedCount(Math.floor((blogs.length * progress) / 100));
              setCurrentBlog(blogs[Math.floor((blogs.length * progress) / 100)]?.title || '');
            });
            
            onClose();
          } catch (error) {
            toast.error('Error processing CSV file');
            console.error('CSV processing error:', error);
          } finally {
            setIsUploading(false);
            setCurrentBlog('');
            setProcessedCount(0);
            setTotalCount(0);
          }
        },
        header: true,
        skipEmptyLines: true
      });
    }
  }, [onUpload, onClose]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv']
    },
    maxFiles: 1,
    disabled: isUploading
  });

  return (
    <div className="neu-flat p-6 space-y-4">
      <h2 className="text-xl font-semibold mb-4">Bulk Upload Blog Posts</h2>
      
      <div
        {...getRootProps()}
        className={`neu-pressed p-8 text-center cursor-pointer transition-colors
          ${isDragActive ? 'bg-blue-50' : ''} 
          ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="w-12 h-12 mx-auto mb-4 text-blue-600" />
        {isUploading ? (
          <div className="space-y-4">
            <p>Uploading blog posts... {Math.round(uploadProgress)}%</p>
            <p className="text-sm text-gray-600">
              Processing: {currentBlog}
            </p>
            <p className="text-sm text-gray-600">
              {processedCount} of {totalCount} posts uploaded
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          </div>
        ) : isDragActive ? (
          <p>Drop the CSV file here...</p>
        ) : (
          <div>
            <p className="mb-2">Drag & drop a CSV file here, or click to select</p>
            <p className="text-sm text-gray-600">
              CSV should include: title, content, excerpt, coverImage, category, tags, status, publishDate, featured, metaTitle, metaDescription, keywords
            </p>
          </div>
        )}
      </div>

      <div className="mt-4 p-4 neu-pressed">
        <h3 className="font-semibold mb-2">CSV Format Example:</h3>
        <pre className="text-sm overflow-x-auto">
          title,content,excerpt,coverImage,category,tags,status,publishDate,featured,metaTitle,metaDescription,keywords
          "First Blog Post","# Content here...","Short excerpt","image_url","Technology","web,coding","published","2024-03-15","true","SEO Title","SEO Description","keyword1,keyword2"
          "Second Blog Post","# Another post...","Another excerpt","image_url","Design","design,ui","draft","","false","SEO Title","SEO Description","keyword1,keyword2"
        </pre>
      </div>

      <div className="flex justify-end gap-4 mt-4">
        <button
          onClick={onClose}
          className="neu-button px-4 py-2 text-red-600"
          disabled={isUploading}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}