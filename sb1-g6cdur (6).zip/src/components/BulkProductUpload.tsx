import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { Upload } from 'lucide-react';
import { ProductFormData } from '../types/product';
import toast from 'react-hot-toast';

interface BulkProductUploadProps {
  onUpload: (products: ProductFormData[], onProgress: (progress: number) => void) => Promise<void>;
  onClose: () => void;
}

export default function BulkProductUpload({ onUpload, onClose }: BulkProductUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [currentProduct, setCurrentProduct] = useState('');
  const [processedCount, setProcessedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  const handleProgress = (progress: number) => {
    setUploadProgress(progress);
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setIsUploading(true);
      Papa.parse(file, {
        complete: async (results) => {
          try {
            const products = results.data
              .filter((row: any) => row.title)
              .map((row: any) => ({
                title: row.title,
                author: row.author || '',
                description: row.description || '',
                price: parseFloat(row.price) || 0,
                coverImage: row.coverImage || '',
                pdfURL: row.pdfURL || '',
                isbn: row.isbn || '',
                pageCount: parseInt(row.pageCount) || 0,
                language: row.language || 'Bengali',
                publisher: row.publisher || '',
                publishDate: row.publishDate || '',
                edition: row.edition || '',
                coverType: row.coverType || 'Paperback',
                dimensions: {
                  width: parseFloat(row.width) || 0,
                  height: parseFloat(row.height) || 0,
                  depth: parseFloat(row.depth) || 0,
                  unit: row.dimensionUnit || 'cm'
                },
                weight: {
                  value: parseFloat(row.weight) || 0,
                  unit: row.weightUnit || 'g'
                },
                stock: parseInt(row.stock) || 0,
                categoryName: row.category ? row.category.trim() : null
              }));

            if (products.length === 0) {
              toast.error('No valid product data found in CSV');
              return;
            }

            setTotalCount(products.length);
            
            await onUpload(products, (progress) => {
              handleProgress(progress);
              setProcessedCount(Math.floor((products.length * progress) / 100));
              setCurrentProduct(products[Math.floor((products.length * progress) / 100)]?.title || '');
            });
            
            onClose();
          } catch (error) {
            toast.error('Error processing CSV file');
            console.error('CSV processing error:', error);
          } finally {
            setIsUploading(false);
            setCurrentProduct('');
            setProcessedCount(0);
            setTotalCount(0);
          }
        },
        header: true,
        skipEmptyLines: true
      });
    }
  }, [onUpload, onClose]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv']
    },
    maxFiles: 1,
    disabled: isUploading
  });

  return (
    <div className="neu-flat p-6 space-y-4">
      <h2 className="text-xl font-semibold mb-4">Bulk Upload Products</h2>
      
      <div
        {...getRootProps()}
        className={`neu-pressed p-8 text-center cursor-pointer transition-colors
          ${isDragActive ? 'bg-blue-50' : ''} 
          ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="w-12 h-12 mx-auto mb-4 text-blue-600" />
        {isUploading ? (
          <div className="space-y-4">
            <p>Uploading products... {Math.round(uploadProgress)}%</p>
            <p className="text-sm text-gray-600">
              Processing: {currentProduct}
            </p>
            <p className="text-sm text-gray-600">
              {processedCount} of {totalCount} products uploaded
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          </div>
        ) : isDragActive ? (
          <p>Drop the CSV file here...</p>
        ) : (
          <div>
            <p className="mb-2">Drag & drop a CSV file here, or click to select</p>
            <p className="text-sm text-gray-600">
              CSV should include: title, author, description, price, coverImage, pdfURL, isbn, pageCount, language, publisher, publishDate, edition, coverType, width, height, depth, dimensionUnit, weight, weightUnit, stock, category
            </p>
          </div>
        )}
      </div>

      <div className="mt-4 p-4 neu-pressed">
        <h3 className="font-semibold mb-2">CSV Format Example:</h3>
        <pre className="text-sm overflow-x-auto">
          title,author,category,price,coverImage,pdfURL,isbn,pageCount,language,publisher,publishDate,edition,coverType,width,height,depth,dimensionUnit,weight,weightUnit,stock
          "The Art of Programming","John Doe","Programming",599,"image_url","pdf_url","123-456-789",350,"English","Tech Books","2024-03-15","2nd","Paperback",15,21,2.5,"cm",450,"g",100
          "Data Structures","Jane Smith","Computer Science",699,"image_url","pdf_url","987-654-321",400,"English","Code Press","2024-03-15","1st","Hardcover",16,22,3,"cm",550,"g",50
        </pre>
      </div>

      <div className="flex justify-end gap-4 mt-4">
        <button
          onClick={onClose}
          className="neu-button px-4 py-2 text-red-600"
          disabled={isUploading}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}