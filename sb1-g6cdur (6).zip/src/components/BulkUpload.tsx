import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import Papa from 'papaparse';
import { Upload } from 'lucide-react';
import { BulkUploadData } from '../types/book';
import toast from 'react-hot-toast';

interface BulkUploadProps {
  onUpload: (books: BulkUploadData[], onProgress: (progress: number) => void) => Promise<void>;
  onClose: () => void;
}

export default function BulkUpload({ onUpload, onClose }: BulkUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const handleProgress = (progress: number) => {
    setUploadProgress(progress);
  };

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setIsUploading(true);
      Papa.parse(file, {
        complete: async (results) => {
          try {
            const books = results.data
              .filter((row: any) => row.bookName && row.authorName)
              .map((row: any) => ({
                bookName: row.bookName,
                authorName: row.authorName,
                longSummary: row.longSummary || '',
                audioURL: row.audioURL || '',
                pdfURL: row.pdfURL || '',
                coverImageURL: row.coverImageURL || '',
                categoryName: row.category ? row.category.trim() : null
              }));

            if (books.length === 0) {
              toast.error('No valid book data found in CSV');
              return;
            }

            await onUpload(books, handleProgress);
            onClose();
          } catch (error) {
            toast.error('Error processing CSV file');
            console.error('CSV processing error:', error);
          } finally {
            setIsUploading(false);
          }
        },
        header: true,
        skipEmptyLines: true
      });
    }
  }, [onUpload, onClose]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv']
    },
    maxFiles: 1,
    disabled: isUploading
  });

  return (
    <div className="neu-flat p-6 space-y-4">
      <h2 className="text-xl font-semibold mb-4">Bulk Upload Books</h2>
      
      <div
        {...getRootProps()}
        className={`neu-pressed p-8 text-center cursor-pointer transition-colors
          ${isDragActive ? 'bg-blue-50' : ''} 
          ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="w-12 h-12 mx-auto mb-4 text-blue-600" />
        {isUploading ? (
          <div className="space-y-4">
            <p>Uploading books... {Math.round(uploadProgress)}%</p>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
          </div>
        ) : isDragActive ? (
          <p>Drop the CSV file here...</p>
        ) : (
          <div>
            <p className="mb-2">Drag & drop a CSV file here, or click to select</p>
            <p className="text-sm text-gray-600">
              CSV should include: bookName, authorName, longSummary, audioURL, pdfURL, coverImageURL, category
            </p>
          </div>
        )}
      </div>

      <div className="mt-4 p-4 neu-pressed">
        <h3 className="font-semibold mb-2">CSV Format Example:</h3>
        <pre className="text-sm overflow-x-auto">
          bookName,authorName,category,longSummary,audioURL,pdfURL,coverImageURL
          "The Almanack of Naval Ravikant","Eric Jorgenson","Philosophy","Summary text...","audio_url","pdf_url","image_url"
          "Atomic Habits","James Clear","Self Help","Summary text...","audio_url","pdf_url","image_url"
        </pre>
      </div>

      <div className="flex justify-end gap-4 mt-4">
        <button
          onClick={onClose}
          className="neu-button px-4 py-2 text-red-600"
          disabled={isUploading}
        >
          Cancel
        </button>
      </div>
    </div>
  );
}