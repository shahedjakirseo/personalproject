import React, { useState } from 'react';
import { useCategories } from '../hooks/useCategories';
import { Category } from '../types/book';
import { X } from 'lucide-react';
import { getUniqueCategories } from '../utils/categoryUtils';
import toast from 'react-hot-toast';

interface CategorySelectProps {
  selectedCategory: Category | null;
  onChange: (category: Category | null) => void;
}

export default function CategorySelect({ selectedCategory, onChange }: CategorySelectProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState<Category[]>([]);
  const { searchCategories, addCategory } = useCategories();

  const handleSearch = async (value: string) => {
    setSearchTerm(value);
    if (value.length >= 3) {
      const results = await searchCategories(value);
      setSuggestions(getUniqueCategories(results));
    } else {
      setSuggestions([]);
    }
  };

  const handleSelect = async (category: Category) => {
    onChange(category);
    setSearchTerm('');
    setSuggestions([]);
  };

  const handleRemove = () => {
    onChange(null);
  };

  const handleCreateCategory = async () => {
    if (searchTerm.length < 3) {
      toast.error('Category name must be at least 3 characters');
      return;
    }

    try {
      const newCategory = await addCategory(searchTerm);
      handleSelect(newCategory);
    } catch (error) {
      toast.error('Failed to create category');
    }
  };

  return (
    <div className="space-y-4">
      {selectedCategory ? (
        <div className="flex flex-wrap gap-2 mb-2">
          <div className="neu-flat px-3 py-1 text-sm flex items-center gap-2">
            {selectedCategory.name}
            <button
              onClick={handleRemove}
              className="text-gray-500 hover:text-red-600"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        </div>
      ) : (
        <div className="relative">
          <input
            type="text"
            className="neu-input w-full"
            placeholder="Type to search or create category..."
            value={searchTerm}
            onChange={e => handleSearch(e.target.value)}
          />

          {searchTerm.length >= 3 && suggestions.length === 0 && (
            <div className="neu-flat mt-2 p-2">
              <button
                onClick={handleCreateCategory}
                className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded"
              >
                Create "{searchTerm}"
              </button>
            </div>
          )}

          {suggestions.length > 0 && (
            <div className="neu-flat mt-2 p-2">
              {suggestions.map(category => (
                <button
                  key={category.id}
                  onClick={() => handleSelect(category)}
                  className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded"
                >
                  {category.name}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}