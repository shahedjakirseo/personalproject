import React, { useState } from 'react';
import { PlusCircle, X } from 'lucide-react';
import { Chapter, Lesson } from '../types/course';

interface ChapterFormProps {
  onSubmit: (data: Omit<Chapter, 'id'>) => Promise<void>;
  initialData?: Chapter;
  onCancel: () => void;
  chapterOrder: number;
}

export default function ChapterForm({ onSubmit, initialData, onCancel, chapterOrder }: ChapterFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Omit<Chapter, 'id'>>({
    title: initialData?.title || '',
    description: initialData?.description || '',
    lessons: initialData?.lessons || [],
    order: chapterOrder
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Chapter Title <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full"
          value={formData.title}
          onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Description <span className="text-red-500">*</span>
        </label>
        <textarea
          required
          className="neu-input w-full h-24"
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>
              <PlusCircle className="w-4 h-4" />
              {initialData ? 'Update' : 'Create'} Chapter
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}