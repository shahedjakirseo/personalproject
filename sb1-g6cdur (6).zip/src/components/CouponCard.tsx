import React from 'react';
import { format } from 'date-fns';
import { Edit2, Trash2, Tag, Calendar, PercentIcon, DollarSign, Power } from 'lucide-react';
import { CouponCardProps } from '../types/coupon';

const formatPrice = (amount: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export default function CouponCard({ 
  coupon, onEdit, onDelete, onToggleStatus 
}: CouponCardProps) {
  const isExpired = coupon.endDate && new Date() > coupon.endDate;
  const isNotStarted = new Date() < coupon.startDate;

  return (
    <div className="neu-flat p-6 space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">{coupon.code}</h3>
          <p className="text-sm text-gray-600">{coupon.description}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={onToggleStatus}
            className={`neu-button p-2 ${coupon.isActive ? 'text-green-600' : 'text-gray-400'}`}
            title={coupon.isActive ? 'Deactivate' : 'Activate'}
          >
            <Power className="w-4 h-4" />
          </button>
          <button
            onClick={onEdit}
            className="neu-button p-2 text-blue-600"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={onDelete}
            className="neu-button p-2 text-red-600"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-gray-600">
          {coupon.discountType === 'percentage' ? (
            <>
              <PercentIcon className="w-3 h-3" />
              {coupon.discountValue}% off
            </>
          ) : (
            <>
              <DollarSign className="w-3 h-3" />
              {formatPrice(coupon.discountValue)} off
            </>
          )}
        </div>
        {coupon.applicableProducts && (
          <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-blue-600">
            <Tag className="w-3 h-3" />
            {coupon.applicableProducts.length} products
          </div>
        )}
        <div className={`neu-button px-3 py-1 text-sm flex items-center gap-1 
          ${isExpired ? 'text-red-600' : isNotStarted ? 'text-orange-600' : 'text-green-600'}`}
        >
          <Calendar className="w-3 h-3" />
          {isExpired ? 'Expired' : isNotStarted ? 'Not Started' : 'Active'}
        </div>
      </div>

      <div className="space-y-2 text-sm">
        <div className="flex justify-between text-gray-600">
          <span>Min. Purchase:</span>
          <span>{formatPrice(coupon.minPurchaseAmount)}</span>
        </div>
        <div className="flex justify-between text-gray-600">
          <span>Max. Discount:</span>
          <span>{formatPrice(coupon.maxDiscountAmount)}</span>
        </div>
        <div className="flex justify-between text-gray-600">
          <span>Usage:</span>
          <span>{coupon.usageCount} / {coupon.usageLimit || '∞'}</span>
        </div>
      </div>

      <div className="text-xs text-gray-500 space-y-1">
        <div>Valid from: {format(coupon.startDate, 'MMM dd, yyyy')}</div>
        {coupon.endDate && (
          <div>Expires: {format(coupon.endDate, 'MMM dd, yyyy')}</div>
        )}
      </div>
    </div>
  );
}