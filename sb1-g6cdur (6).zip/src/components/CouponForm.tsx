import React, { useState } from 'react';
import { format } from 'date-fns';
import { Coupon, CouponFormData } from '../types/coupon';
import { useProducts } from '../hooks/useProducts';

interface CouponFormProps {
  onSubmit: (data: CouponFormData) => Promise<void>;
  initialData?: Coupon;
  onCancel: () => void;
}

const formatPrice = (amount: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export default function CouponForm({ onSubmit, initialData, onCancel }: CouponFormProps) {
  const { products, loading: productsLoading } = useProducts();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<CouponFormData>({
    code: initialData?.code || '',
    description: initialData?.description || '',
    discountType: initialData?.discountType || 'fixed',
    discountValue: initialData?.discountValue || 0,
    minPurchaseAmount: initialData?.minPurchaseAmount || 0,
    maxDiscountAmount: initialData?.maxDiscountAmount || 0,
    startDate: initialData?.startDate ? format(initialData.startDate, 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
    endDate: initialData?.endDate ? format(initialData.endDate, 'yyyy-MM-dd') : null,
    usageLimit: initialData?.usageLimit || 0,
    isActive: initialData?.isActive ?? true,
    applicableProducts: initialData?.applicableProducts || null
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Coupon Code <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full uppercase"
          value={formData.code}
          onChange={e => setFormData(prev => ({ 
            ...prev, 
            code: e.target.value.toUpperCase() 
          }))}
          placeholder="e.g., SUMMER2024"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
        <textarea
          className="neu-input w-full h-24"
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
          placeholder="Describe the coupon..."
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Discount Type</label>
          <select
            className="neu-input w-full"
            value={formData.discountType}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              discountType: e.target.value as 'fixed' | 'percentage' 
            }))}
          >
            <option value="fixed">Fixed Amount</option>
            <option value="percentage">Percentage</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Discount Value <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            required
            min="0"
            step={formData.discountType === 'percentage' ? '1' : '1'}
            max={formData.discountType === 'percentage' ? '100' : undefined}
            className="neu-input w-full"
            value={formData.discountValue}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              discountValue: parseFloat(e.target.value) || 0 
            }))}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Min. Purchase Amount
          </label>
          <input
            type="number"
            min="0"
            step="1"
            className="neu-input w-full"
            value={formData.minPurchaseAmount}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              minPurchaseAmount: parseFloat(e.target.value) || 0 
            }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Max. Discount Amount
          </label>
          <input
            type="number"
            min="0"
            step="1"
            className="neu-input w-full"
            value={formData.maxDiscountAmount}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              maxDiscountAmount: parseFloat(e.target.value) || 0 
            }))}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Start Date <span className="text-red-500">*</span>
          </label>
          <input
            type="date"
            required
            className="neu-input w-full"
            value={formData.startDate}
            onChange={e => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
          <input
            type="date"
            className="neu-input w-full"
            value={formData.endDate || ''}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              endDate: e.target.value || null 
            }))}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Usage Limit</label>
        <input
          type="number"
          min="0"
          className="neu-input w-full"
          value={formData.usageLimit}
          onChange={e => setFormData(prev => ({ 
            ...prev, 
            usageLimit: parseInt(e.target.value) || 0 
          }))}
          placeholder="0 for unlimited"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Applicable Products</label>
        {productsLoading ? (
          <div className="neu-flat p-4 text-center">
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <>
            <select
              multiple
              className="neu-input w-full h-32"
              value={formData.applicableProducts?.map(p => p.id) || []}
              onChange={e => {
                const selectedProducts = Array.from(e.target.selectedOptions)
                  .map(option => products.find(p => p.id === option.value))
                  .filter((p): p is NonNullable<typeof p> => p !== undefined);
                
                setFormData(prev => ({ 
                  ...prev, 
                  applicableProducts: selectedProducts.length > 0 ? selectedProducts : null 
                }));
              }}
            >
              <option value="">All Products</option>
              {products.map(product => (
                <option key={product.id} value={product.id}>
                  {product.title} ({formatPrice(product.price)})
                </option>
              ))}
            </select>
            <p className="mt-1 text-sm text-gray-500">
              Leave empty to apply to all products
            </p>
          </>
        )}
      </div>

      <div>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={formData.isActive}
            onChange={e => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
            className="neu-input h-4 w-4"
          />
          <span className="text-sm font-medium text-gray-700">Active</span>
        </label>
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading || productsLoading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>{initialData ? 'Update' : 'Create'} Coupon</>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}