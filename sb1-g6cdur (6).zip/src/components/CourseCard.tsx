import React from 'react';
import { Edit2, Trash2, Clock, BookOpen, Award } from 'lucide-react';
import { Course } from '../types/course';
import { formatDuration } from '../utils/stringUtils';

interface CourseCardProps {
  course: Course;
  onEdit: () => void;
  onDelete: () => void;
  onClick: () => void;
}

export default function CourseCard({ course, onEdit, onDelete, onClick }: CourseCardProps) {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  return (
    <div 
      className="neu-flat p-6 space-y-4 cursor-pointer transition-transform hover:scale-[1.02]"
      onClick={onClick}
    >
      <div className="relative">
        <img
          src={course.coverImage}
          alt={course.title}
          className="w-full h-48 object-cover rounded-lg"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=800&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZWR1Y2F0aW9ufGVufDB8fDB8fHww';
          }}
        />
        <div className="absolute top-2 right-2 flex gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit();
            }}
            className="neu-button p-2 text-blue-600 bg-white/90"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="neu-button p-2 text-red-600 bg-white/90"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="space-y-2">
        <h3 className="text-xl font-semibold text-gray-900">{course.title}</h3>
        <p className="text-gray-600 line-clamp-2">{course.shortDescription}</p>
      </div>

      <div className="flex items-center gap-4">
        <img
          src={course.instructor.photoURL}
          alt={course.instructor.name}
          className="w-10 h-10 rounded-full object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(course.instructor.name)}`;
          }}
        />
        <div>
          <p className="text-sm font-medium text-gray-900">{course.instructor.name}</p>
          <p className="text-xs text-gray-500">{course.instructor.expertise.join(', ')}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 text-sm">
        <div className="neu-button px-3 py-1 flex items-center gap-1 text-blue-600">
          <Clock className="w-3 h-3" />
          {formatDuration(course.totalDuration)}
        </div>
        <div className="neu-button px-3 py-1 flex items-center gap-1 text-green-600">
          <BookOpen className="w-3 h-3" />
          {course.totalLessons} lessons
        </div>
        <div className="neu-button px-3 py-1 flex items-center gap-1 text-purple-600">
          <Award className="w-3 h-3" />
          {course.level}
        </div>
      </div>

      <div className="flex justify-between items-center pt-4 border-t">
        <div className="text-2xl font-bold text-gray-900">
          {formatPrice(course.price)}
        </div>
        <span className={`px-2 py-1 text-sm rounded-full ${
          course.status === 'published' 
            ? 'bg-green-100 text-green-800' 
            : 'bg-yellow-100 text-yellow-800'
        }`}>
          {course.status}
        </span>
      </div>
    </div>
  );
}