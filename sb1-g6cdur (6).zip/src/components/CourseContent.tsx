import React, { useState, useEffect } from 'react';
import { PlusCircle, Edit2, Trash2, GripVertical, ChevronDown, ChevronUp, Play, Lock } from 'lucide-react';
import { Course, Chapter, Lesson } from '../types/course';
import Modal from './Modal';
import ChapterForm from './ChapterForm';
import LessonForm from './LessonForm';
import { formatDuration } from '../utils/stringUtils';

interface CourseContentProps {
  course: Course;
  onUpdateCourse: (courseId: string, data: Partial<Course>) => Promise<void>;
}

export default function CourseContent({ course, onUpdateCourse }: CourseContentProps) {
  const [expandedChapters, setExpandedChapters] = useState<string[]>([]);
  const [showAddChapter, setShowAddChapter] = useState(false);
  const [showAddLesson, setShowAddLesson] = useState<string | null>(null);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [editingLesson, setEditingLesson] = useState<{ chapter: Chapter; lesson: Lesson } | null>(null);
  const [showDeleteChapter, setShowDeleteChapter] = useState<Chapter | null>(null);
  const [showDeleteLesson, setShowDeleteLesson] = useState<{ chapter: Chapter; lesson: Lesson } | null>(null);

  // Auto-expand the first chapter on initial load
  useEffect(() => {
    if (course.chapters.length > 0 && expandedChapters.length === 0) {
      setExpandedChapters([course.chapters[0].id]);
    }
  }, [course.chapters]);

  const toggleChapter = (chapterId: string) => {
    setExpandedChapters(prev =>
      prev.includes(chapterId)
        ? prev.filter(id => id !== chapterId)
        : [...prev, chapterId]
    );
  };

  const handleAddChapter = async (chapterData: Omit<Chapter, 'id'>) => {
    const newChapter = {
      ...chapterData,
      id: `chapter_${Date.now()}`,
      lessons: []
    };

    const updatedChapters = [...course.chapters, newChapter];
    await onUpdateCourse(course.id, { chapters: updatedChapters });
    setShowAddChapter(false);
    setExpandedChapters(prev => [...prev, newChapter.id]);
  };

  const handleEditChapter = async (chapterData: Omit<Chapter, 'id'>) => {
    if (!editingChapter) return;

    const updatedChapters = course.chapters.map(chapter =>
      chapter.id === editingChapter.id
        ? { ...chapter, ...chapterData, lessons: chapter.lessons }
        : chapter
    );

    await onUpdateCourse(course.id, { chapters: updatedChapters });
    setEditingChapter(null);
  };

  const handleDeleteChapter = async (chapter: Chapter) => {
    const updatedChapters = course.chapters.filter(c => c.id !== chapter.id);
    const totalLessons = course.totalLessons - chapter.lessons.length;
    const totalDuration = course.totalDuration - chapter.lessons.reduce((sum, lesson) => sum + lesson.duration, 0);

    await onUpdateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons,
      totalDuration
    });
    setShowDeleteChapter(null);
  };

  const handleAddLesson = async (chapterId: string, lessonData: Omit<Lesson, 'id'>) => {
    const newLesson = {
      ...lessonData,
      id: `lesson_${Date.now()}`
    };

    const updatedChapters = course.chapters.map(chapter =>
      chapter.id === chapterId
        ? { ...chapter, lessons: [...chapter.lessons, newLesson] }
        : chapter
    );

    await onUpdateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons: course.totalLessons + 1,
      totalDuration: course.totalDuration + lessonData.duration
    });
    setShowAddLesson(null);
  };

  const handleEditLesson = async (lessonData: Omit<Lesson, 'id'>) => {
    if (!editingLesson) return;

    const oldDuration = editingLesson.lesson.duration;
    const durationDiff = lessonData.duration - oldDuration;

    const updatedChapters = course.chapters.map(chapter =>
      chapter.id === editingLesson.chapter.id
        ? {
            ...chapter,
            lessons: chapter.lessons.map(lesson =>
              lesson.id === editingLesson.lesson.id
                ? { ...lesson, ...lessonData }
                : lesson
            )
          }
        : chapter
    );

    await onUpdateCourse(course.id, { 
      chapters: updatedChapters,
      totalDuration: course.totalDuration + durationDiff
    });
    setEditingLesson(null);
  };

  const handleDeleteLesson = async (chapter: Chapter, lesson: Lesson) => {
    const updatedChapters = course.chapters.map(c =>
      c.id === chapter.id
        ? { ...c, lessons: c.lessons.filter(l => l.id !== lesson.id) }
        : c
    );

    await onUpdateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons: course.totalLessons - 1,
      totalDuration: course.totalDuration - lesson.duration
    });
    setShowDeleteLesson(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-gray-900">Course Content</h3>
        <button
          onClick={() => setShowAddChapter(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Add Chapter
        </button>
      </div>

      <div className="space-y-4">
        {course.chapters.map((chapter, index) => (
          <div key={chapter.id} className="neu-flat">
            <div
              className="p-4 flex items-center justify-between cursor-pointer"
              onClick={() => toggleChapter(chapter.id)}
            >
              <div className="flex items-center gap-4">
                <GripVertical className="w-4 h-4 text-gray-400" />
                <div>
                  <h4 className="font-medium text-gray-900">
                    Chapter {index + 1}: {chapter.title}
                  </h4>
                  <p className="text-sm text-gray-500">
                    {chapter.lessons.length} lessons • {formatDuration(
                      chapter.lessons.reduce((sum, lesson) => sum + lesson.duration, 0)
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setEditingChapter(chapter);
                  }}
                  className="neu-button p-2 text-blue-600"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowDeleteChapter(chapter);
                  }}
                  className="neu-button p-2 text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                {expandedChapters.includes(chapter.id) ? (
                  <ChevronUp className="w-4 h-4" />
                ) : (
                  <ChevronDown className="w-4 h-4" />
                )}
              </div>
            </div>

            {expandedChapters.includes(chapter.id) && (
              <div className="p-4 border-t">
                <div className="space-y-2">
                  {chapter.lessons.map((lesson, lessonIndex) => (
                    <div
                      key={lesson.id}
                      className="neu-pressed p-3 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-4">
                        <GripVertical className="w-4 h-4 text-gray-400" />
                        <div>
                          <div className="flex items-center gap-2">
                            <h5 className="font-medium text-gray-900">
                              {lessonIndex + 1}. {lesson.title}
                            </h5>
                            {lesson.isPreview && (
                              <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                                Preview
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-gray-500">
                            {formatDuration(lesson.duration)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {lesson.videoURL && (
                          <Play className="w-4 h-4 text-green-600" />
                        )}
                        {!lesson.isPreview && (
                          <Lock className="w-4 h-4 text-gray-400" />
                        )}
                        <button
                          onClick={() => setEditingLesson({ chapter, lesson })}
                          className="neu-button p-2 text-blue-600"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setShowDeleteLesson({ chapter, lesson })}
                          className="neu-button p-2 text-red-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setShowAddLesson(chapter.id)}
                  className="mt-4 neu-button px-4 py-2 text-blue-600 flex items-center gap-2 w-full justify-center"
                >
                  <PlusCircle className="w-4 h-4" />
                  Add Lesson
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Add Chapter Modal */}
      <Modal
        isOpen={showAddChapter}
        onClose={() => setShowAddChapter(false)}
        title="Add New Chapter"
      >
        <ChapterForm
          onSubmit={handleAddChapter}
          onCancel={() => setShowAddChapter(false)}
          chapterOrder={course.chapters.length + 1}
        />
      </Modal>

      {/* Edit Chapter Modal */}
      <Modal
        isOpen={!!editingChapter}
        onClose={() => setEditingChapter(null)}
        title="Edit Chapter"
      >
        <ChapterForm
          initialData={editingChapter || undefined}
          onSubmit={handleEditChapter}
          onCancel={() => setEditingChapter(null)}
          chapterOrder={editingChapter?.order || 0}
        />
      </Modal>

      {/* Add Lesson Modal */}
      <Modal
        isOpen={!!showAddLesson}
        onClose={() => setShowAddLesson(null)}
        title="Add New Lesson"
      >
        <LessonForm
          onSubmit={(data) => handleAddLesson(showAddLesson!, data)}
          onCancel={() => setShowAddLesson(null)}
          lessonOrder={
            course.chapters.find(c => c.id === showAddLesson)?.lessons.length || 0
          }
        />
      </Modal>

      {/* Edit Lesson Modal */}
      <Modal
        isOpen={!!editingLesson}
        onClose={() => setEditingLesson(null)}
        title="Edit Lesson"
      >
        <LessonForm
          initialData={editingLesson?.lesson}
          onSubmit={handleEditLesson}
          onCancel={() => setEditingLesson(null)}
          lessonOrder={editingLesson?.lesson.order || 0}
        />
      </Modal>

      {/* Delete Chapter Confirmation */}
      <Modal
        isOpen={!!showDeleteChapter}
        onClose={() => setShowDeleteChapter(null)}
        title="Delete Chapter"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete this chapter and all its lessons? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => showDeleteChapter && handleDeleteChapter(showDeleteChapter)}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => setShowDeleteChapter(null)}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete Lesson Confirmation */}
      <Modal
        isOpen={!!showDeleteLesson}
        onClose={() => setShowDeleteLesson(null)}
        title="Delete Lesson"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete this lesson? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => showDeleteLesson && handleDeleteLesson(showDeleteLesson.chapter, showDeleteLesson.lesson)}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => setShowDeleteLesson(null)}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}