import React, { useState } from 'react';
import { PlusCircle, X } from 'lucide-react';
import { Course, CourseFormData } from '../types/course';

interface CourseFormProps {
  onSubmit: (data: CourseFormData) => Promise<void>;
  initialData?: Course;
  onCancel: () => void;
}

export default function CourseForm({ onSubmit, initialData, onCancel }: CourseFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<CourseFormData>({
    title: initialData?.title || '',
    shortDescription: initialData?.shortDescription || '',
    description: initialData?.description || '',
    coverImage: initialData?.coverImage || '',
    previewVideo: initialData?.previewVideo || '',
    instructor: initialData?.instructor ? {
      name: initialData.instructor.name,
      bio: initialData.instructor.bio,
      photoURL: initialData.instructor.photoURL,
      expertise: initialData.instructor.expertise
    } : {
      name: '',
      bio: '',
      photoURL: '',
      expertise: []
    },
    price: initialData?.price || 0,
    status: initialData?.status || 'draft',
    level: initialData?.level || 'beginner',
    prerequisites: initialData?.prerequisites || [],
    tags: initialData?.tags || []
  });

  const [newPrerequisite, setNewPrerequisite] = useState('');
  const [newTag, setNewTag] = useState('');
  const [newExpertise, setNewExpertise] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  const handleAddPrerequisite = () => {
    if (newPrerequisite.trim()) {
      setFormData(prev => ({
        ...prev,
        prerequisites: [...prev.prerequisites, newPrerequisite.trim()]
      }));
      setNewPrerequisite('');
    }
  };

  const handleAddTag = () => {
    if (newTag.trim()) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const handleAddExpertise = () => {
    if (newExpertise.trim()) {
      setFormData(prev => ({
        ...prev,
        instructor: {
          ...prev.instructor,
          expertise: [...prev.instructor.expertise, newExpertise.trim()]
        }
      }));
      setNewExpertise('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Course Title <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full"
          value={formData.title}
          onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Short Description <span className="text-red-500">*</span>
        </label>
        <textarea
          required
          className="neu-input w-full h-20"
          value={formData.shortDescription}
          onChange={e => setFormData(prev => ({ ...prev, shortDescription: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Full Description <span className="text-red-500">*</span>
        </label>
        <textarea
          required
          className="neu-input w-full h-32"
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Cover Image URL <span className="text-red-500">*</span>
        </label>
        <input
          type="url"
          required
          className="neu-input w-full"
          value={formData.coverImage}
          onChange={e => setFormData(prev => ({ ...prev, coverImage: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Preview Video URL
        </label>
        <input
          type="url"
          className="neu-input w-full"
          value={formData.previewVideo}
          onChange={e => setFormData(prev => ({ ...prev, previewVideo: e.target.value }))}
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900">Instructor Details</h3>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            className="neu-input w-full"
            value={formData.instructor.name}
            onChange={e => setFormData(prev => ({
              ...prev,
              instructor: { ...prev.instructor, name: e.target.value }
            }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Bio <span className="text-red-500">*</span>
          </label>
          <textarea
            required
            className="neu-input w-full h-24"
            value={formData.instructor.bio}
            onChange={e => setFormData(prev => ({
              ...prev,
              instructor: { ...prev.instructor, bio: e.target.value }
            }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Photo URL <span className="text-red-500">*</span>
          </label>
          <input
            type="url"
            required
            className="neu-input w-full"
            value={formData.instructor.photoURL}
            onChange={e => setFormData(prev => ({
              ...prev,
              instructor: { ...prev.instructor, photoURL: e.target.value }
            }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Areas of Expertise
          </label>
          <div className="flex gap-2 mb-2">
            <input
              type="text"
              className="neu-input flex-1"
              value={newExpertise}
              onChange={e => setNewExpertise(e.target.value)}
              placeholder="Add area of expertise"
            />
            <button
              type="button"
              onClick={handleAddExpertise}
              className="neu-button px-4 py-2 text-blue-600"
            >
              Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {formData.instructor.expertise.map((item, index) => (
              <div
                key={index}
                className="neu-flat px-3 py-1 text-sm flex items-center gap-2"
              >
                {item}
                <button
                  type="button"
                  onClick={() => setFormData(prev => ({
                    ...prev,
                    instructor: {
                      ...prev.instructor,
                      expertise: prev.instructor.expertise.filter((_, i) => i !== index)
                    }
                  }))}
                  className="text-red-600"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Price (BDT) <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            required
            min="0"
            step="1"
            className="neu-input w-full"
            value={formData.price}
            onChange={e => setFormData(prev => ({ ...prev, price: parseInt(e.target.value) || 0 }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Status <span className="text-red-500">*</span>
          </label>
          <select
            required
            className="neu-input w-full"
            value={formData.status}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              status: e.target.value as 'draft' | 'published' 
            }))}
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Level <span className="text-red-500">*</span>
          </label>
          <select
            required
            className="neu-input w-full"
            value={formData.level}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              level: e.target.value as 'beginner' | 'intermediate' | 'advanced' 
            }))}
          >
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Prerequisites
        </label>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            className="neu-input flex-1"
            value={newPrerequisite}
            onChange={e => setNewPrerequisite(e.target.value)}
            placeholder="Add prerequisite"
          />
          <button
            type="button"
            onClick={handleAddPrerequisite}
            className="neu-button px-4 py-2 text-blue-600"
          >
            Add
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {formData.prerequisites.map((prerequisite, index) => (
            <div
              key={index}
              className="neu-flat px-3 py-1 text-sm flex items-center gap-2"
            >
              {prerequisite}
              <button
                type="button"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  prerequisites: prev.prerequisites.filter((_, i) => i !== index)
                }))}
                className="text-red-600"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Tags
        </label>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            className="neu-input flex-1"
            value={newTag}
            onChange={e => setNewTag(e.target.value)}
            placeholder="Add tag"
          />
          <button
            type="button"
            onClick={handleAddTag}
            className="neu-button px-4 py-2 text-blue-600"
          >
            Add
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {formData.tags.map((tag, index) => (
            <div
              key={index}
              className="neu-flat px-3 py-1 text-sm flex items-center gap-2"
            >
              {tag}
              <button
                type="button"
                onClick={() => setFormData(prev => ({
                  ...prev,
                  tags: prev.tags.filter((_, i) => i !== index)
                }))}
                className="text-red-600"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>
              <PlusCircle className="w-4 h-4" />
              {initialData ? 'Update' : 'Create'} Course
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}