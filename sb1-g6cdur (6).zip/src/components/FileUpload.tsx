import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X } from 'lucide-react';
import { uploadFile } from '../lib/uploadUtils';

interface FileUploadProps {
  accept: Record<string, string[]>;
  path: string;
  value: string;
  onChange: (url: string) => void;
  onProgress?: (progress: number) => void;
  maxSize?: number;
}

export default function FileUpload({ 
  accept, 
  path, 
  value, 
  onChange, 
  onProgress = () => {}, 
  maxSize = 5242880 // 5MB default
}: FileUploadProps) {
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      try {
        const url = await uploadFile(file, path, ({ progress }) => {
          onProgress(progress);
        });
        onChange(url);
      } catch (error) {
        console.error('Upload error:', error);
      }
    }
  }, [path, onChange, onProgress]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept,
    maxFiles: 1,
    maxSize
  });

  return (
    <div className="space-y-2">
      <div
        {...getRootProps()}
        className={`neu-pressed p-4 text-center cursor-pointer transition-colors
          ${isDragActive ? 'bg-blue-50' : ''}`}
      >
        <input {...getInputProps()} />
        <Upload className="w-8 h-8 mx-auto mb-2 text-blue-600" />
        <p className="text-sm text-gray-600">
          {isDragActive
            ? "Drop the file here..."
            : "Drag & drop a file here, or click to select"}
        </p>
      </div>

      {value && (
        <div className="flex items-center gap-2 p-2 neu-flat">
          <a 
            href={value} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex-1 text-sm text-blue-600 truncate hover:underline"
          >
            {value}
          </a>
          <button
            onClick={() => onChange('')}
            className="neu-button p-1 text-red-600"
            title="Remove file"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}