import React, { useState } from 'react';
import { PlusCircle, Upload } from 'lucide-react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Lesson } from '../types/course';
import { uploadFile } from '../lib/uploadUtils';

interface LessonFormProps {
  onSubmit: (data: Omit<Lesson, 'id'>) => Promise<void>;
  initialData?: Lesson;
  onCancel: () => void;
  lessonOrder: number;
}

const modules = {
  toolbar: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    ['blockquote', 'code-block'],
    [{ align: [] }],
    ['link', 'image', 'video'],
    ['clean']
  ]
};

const formats = [
  'header',
  'bold', 'italic', 'underline', 'strike',
  'list', 'bullet',
  'blockquote', 'code-block',
  'align',
  'link', 'image', 'video'
];

export default function LessonForm({ onSubmit, initialData, onCancel, lessonOrder }: LessonFormProps) {
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [formData, setFormData] = useState<Omit<Lesson, 'id'>>({
    title: initialData?.title || '',
    description: initialData?.description || '',
    duration: initialData?.duration || 0,
    videoURL: initialData?.videoURL || '',
    content: initialData?.content || '',
    isPreview: initialData?.isPreview || false,
    order: lessonOrder
  });

  const handleVideoUpload = async (file: File) => {
    try {
      const url = await uploadFile(
        file,
        'lesson-videos',
        ({ progress }) => setUploadProgress(progress)
      );
      setFormData(prev => ({ ...prev, videoURL: url }));
    } catch (error) {
      console.error('Video upload error:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Lesson Title <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full"
          value={formData.title}
          onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Description <span className="text-red-500">*</span>
        </label>
        <textarea
          required
          className="neu-input w-full h-24"
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Video
        </label>
        <div className="space-y-2">
          <div className="flex gap-2">
            <input
              type="url"
              className="neu-input flex-1"
              value={formData.videoURL}
              onChange={e => setFormData(prev => ({ ...prev, videoURL: e.target.value }))}
              placeholder="Enter video URL"
            />
            <label className="neu-button px-4 py-2 text-blue-600 cursor-pointer">
              <input
                type="file"
                accept="video/*"
                className="hidden"
                onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) handleVideoUpload(file);
                }}
              />
              <Upload className="w-4 h-4" />
            </label>
          </div>
          {uploadProgress > 0 && uploadProgress < 100 && (
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Content
        </label>
        <div className="neu-flat p-2">
          <ReactQuill
            theme="snow"
            value={formData.content}
            onChange={content => setFormData(prev => ({ ...prev, content }))}
            modules={modules}
            formats={formats}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Duration (minutes) <span className="text-red-500">*</span>
          </label>
          <input
            type="number"
            required
            min="1"
            className="neu-input w-full"
            value={formData.duration}
            onChange={e => setFormData(prev => ({ 
              ...prev, 
              duration: parseInt(e.target.value) || 0 
            }))}
          />
        </div>

        <div className="flex items-center">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              className="neu-input h-4 w-4"
              checked={formData.isPreview}
              onChange={e => setFormData(prev => ({ 
                ...prev, 
                isPreview: e.target.checked 
              }))}
            />
            <span className="text-sm font-medium text-gray-700">
              Preview Lesson
            </span>
          </label>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>
              <PlusCircle className="w-4 h-4" />
              {initialData ? 'Update' : 'Create'} Lesson
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}