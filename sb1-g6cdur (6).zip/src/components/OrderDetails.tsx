import React from 'react';
import { format } from 'date-fns';
import { FileText } from 'lucide-react';
import { Order, ORDER_STATUSES } from '../types/order';
import { useInvoices } from '../hooks/useInvoices';

interface OrderDetailsProps {
  order: Order;
}

const formatPrice = (amount: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export default function OrderDetails({ order }: OrderDetailsProps) {
  const { generateInvoice } = useInvoices();
  const [generating, setGenerating] = React.useState(false);

  const handleGenerateInvoice = async () => {
    setGenerating(true);
    try {
      const invoice = await generateInvoice(order);
      const invoiceWindow = window.open('', '_blank');
      if (invoiceWindow) {
        const invoiceHtml = `
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="UTF-8">
              <title>Invoice #${invoice.invoiceNumber}</title>
              <style>
                @media print {
                  @page { margin: 0.5cm; }
                }
                body { 
                  font-family: system-ui, -apple-system, sans-serif; 
                  line-height: 1.5;
                  margin: 0;
                  padding: 0;
                }
                .container { 
                  max-width: 800px; 
                  margin: 40px auto; 
                  padding: 20px;
                }
                .header { 
                  text-align: center; 
                  margin-bottom: 40px;
                  padding-bottom: 20px;
                  border-bottom: 1px solid #eee;
                }
                .details { 
                  margin-bottom: 20px;
                  display: grid;
                  grid-template-columns: 1fr 1fr;
                  gap: 20px;
                }
                .details h2 {
                  grid-column: 1 / -1;
                  margin: 0 0 10px 0;
                  color: #374151;
                  font-size: 1.25rem;
                }
                .details p {
                  margin: 0;
                  color: #4B5563;
                }
                .table { 
                  width: 100%; 
                  border-collapse: collapse; 
                  margin: 20px 0;
                }
                .table th, .table td { 
                  padding: 12px; 
                  border-bottom: 1px solid #eee; 
                  text-align: left;
                }
                .table th {
                  background-color: #F9FAFB;
                  font-weight: 600;
                  color: #374151;
                }
                .total { 
                  text-align: right; 
                  margin-top: 20px;
                  padding-top: 20px;
                  border-top: 1px solid #eee;
                }
                .total p {
                  margin: 5px 0;
                  color: #4B5563;
                }
                .total h3 {
                  margin: 10px 0;
                  color: #111827;
                  font-size: 1.5rem;
                }
                @media print {
                  .no-print { display: none; }
                }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1 style="margin: 0; color: #111827;">Invoice #${invoice.invoiceNumber}</h1>
                  <p style="margin: 5px 0; color: #4B5563;">Order #${invoice.orderNumber}</p>
                  <p style="margin: 5px 0; color: #4B5563;">
                    Date: ${format(invoice.createdAt, 'MMM dd, yyyy')}
                  </p>
                </div>

                <div class="details">
                  <h2>Billing Details</h2>
                  <div>
                    <p style="font-weight: 600;">${invoice.billingDetails.name}</p>
                    <p>${invoice.billingDetails.email || ''}</p>
                    <p>${invoice.billingDetails.phone}</p>
                    <p>${invoice.billingDetails.address}</p>
                    <p>${[
                      invoice.billingDetails.city,
                      invoice.billingDetails.state,
                      invoice.billingDetails.postcode,
                      invoice.billingDetails.country
                    ].filter(Boolean).join(', ')}</p>
                  </div>
                  <div style="text-align: right;">
                    <p><strong>Payment Method:</strong> ${invoice.paymentMethod}</p>
                    <p><strong>Status:</strong> ${invoice.status}</p>
                  </div>
                </div>

                <table class="table">
                  <thead>
                    <tr>
                      <th>Item</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${invoice.items.map(item => `
                      <tr>
                        <td>${item.description}</td>
                        <td>${item.quantity}</td>
                        <td>${formatPrice(item.price)}</td>
                        <td>${formatPrice(item.subtotal)}</td>
                      </tr>
                    `).join('')}
                  </tbody>
                </table>

                <div class="total">
                  <p>Subtotal: ${formatPrice(invoice.subtotal)}</p>
                  ${invoice.discount > 0 ? `
                    <p>Discount: -${formatPrice(invoice.discount)}</p>
                  ` : ''}
                  <h3>Total: ${formatPrice(invoice.total)}</h3>
                </div>

                <div class="no-print" style="margin-top: 40px; text-align: center;">
                  <button onclick="window.print()" style="
                    background: #2563EB;
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 16px;
                  ">
                    Print Invoice
                  </button>
                </div>
              </div>
            </body>
          </html>
        `;
        invoiceWindow.document.write(invoiceHtml);
        invoiceWindow.document.close();
      }
    } catch (error) {
      console.error('Error generating invoice:', error);
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Order Header */}
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">Order #{order.orderNumber}</h3>
          <p className="text-sm text-gray-500">
            Placed on {format(order.createdAt, 'MMM dd, yyyy HH:mm')}
          </p>
        </div>
        <div className="flex gap-4">
          <button
            onClick={handleGenerateInvoice}
            disabled={generating}
            className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
          >
            {generating ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
            ) : (
              <>
                <FileText className="w-4 h-4" />
                Generate Invoice
              </>
            )}
          </button>
          <div className={`px-3 py-1 rounded-full text-sm font-medium ${ORDER_STATUSES[order.status].color}`}>
            {ORDER_STATUSES[order.status].label}
          </div>
        </div>
      </div>

      {/* Customer Details */}
      <div className="neu-flat p-4">
        <h4 className="text-lg font-medium text-gray-900 mb-4">Customer Details</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-gray-500">Name</p>
            <p className="text-gray-900">{order.billing.name}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Phone</p>
            <p className="text-gray-900">{order.billing.phone}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Email</p>
            <p className="text-gray-900">{order.billing.email || 'Not provided'}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Payment Method</p>
            <p className="text-gray-900">{order.paymentMethod}</p>
          </div>
        </div>
      </div>

      {/* Shipping Address */}
      <div className="neu-flat p-4">
        <h4 className="text-lg font-medium text-gray-900 mb-4">Shipping Address</h4>
        <p className="text-gray-900">{order.billing.address}</p>
        <p className="text-gray-900">
          {[
            order.billing.city,
            order.billing.state,
            order.billing.postcode,
            order.billing.country
          ].filter(Boolean).join(', ')}
        </p>
      </div>

      {/* Order Items */}
      <div className="neu-flat p-4">
        <h4 className="text-lg font-medium text-gray-900 mb-4">Order Items</h4>
        <div className="divide-y divide-gray-200">
          {order.items.map((item) => (
            <div key={item.product.id} className="py-4 flex justify-between">
              <div className="flex gap-4">
                {item.product.coverImage && (
                  <img
                    src={item.product.coverImage}
                    alt={item.product.title}
                    className="w-16 h-16 object-cover rounded"
                  />
                )}
                <div>
                  <p className="font-medium text-gray-900">{item.product.title}</p>
                  <p className="text-sm text-gray-500">{item.product.author}</p>
                  <p className="text-sm text-gray-500">
                    {formatPrice(item.price)} × {item.quantity}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-medium text-gray-900">{formatPrice(item.subtotal)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Order Summary */}
      <div className="neu-flat p-4">
        <h4 className="text-lg font-medium text-gray-900 mb-4">Order Summary</h4>
        <div className="space-y-2">
          <div className="flex justify-between text-gray-500">
            <span>Subtotal</span>
            <span>{formatPrice(order.subtotal)}</span>
          </div>
          {order.discount > 0 && (
            <div className="flex justify-between text-red-500">
              <span>Discount</span>
              <span>-{formatPrice(order.discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-lg font-medium text-gray-900 pt-2 border-t">
            <span>Total</span>
            <span>{formatPrice(order.total)}</span>
          </div>
        </div>
      </div>

      {/* Order Notes */}
      {order.notes && order.notes.length > 0 && (
        <div className="neu-flat p-4">
          <h4 className="text-lg font-medium text-gray-900 mb-4">Order Notes</h4>
          <div className="space-y-2">
            {order.notes.map((note, index) => (
              <div key={index} className="text-gray-600 bg-gray-50 p-3 rounded">
                {note}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}