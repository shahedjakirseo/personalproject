import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Order, OrderFormData, OrderStatus, ORDER_STATUSES } from '../types/order';
import { useProducts } from '../hooks/useProducts';
import { useCouponValidation } from '../hooks/useCouponValidation';
import toast from 'react-hot-toast';

interface OrderFormProps {
  onSubmit: (data: OrderFormData) => Promise<void>;
  initialData?: Order;
  onCancel: () => void;
}

const formatPrice = (amount: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export default function OrderForm({ onSubmit, initialData, onCancel }: OrderFormProps) {
  const { products } = useProducts();
  const { validateCoupon } = useCouponValidation();
  const [loading, setLoading] = useState(false);
  const [validatingCoupon, setValidatingCoupon] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [couponError, setCouponError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [formData, setFormData] = useState<OrderFormData>({
    status: initialData?.status || 'processing',
    items: initialData?.items || [],
    billing: initialData?.billing || {
      name: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      country: 'Bangladesh',
      postcode: ''
    },
    discount: initialData?.discount || 0,
    notes: initialData?.notes || [],
    paymentMethod: initialData?.paymentMethod || 'Cash on Delivery',
    coupon: initialData?.coupon
  });

  const subtotal = formData.items.reduce((sum, item) => sum + item.subtotal, 0);
  const total = subtotal - (formData.discount || 0);

  const filteredProducts = searchTerm.trim() 
    ? products.filter(p => 
        p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.author.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : products;

  const handleAddItem = (product: any, quantity: number = 1) => {
    const existingItem = formData.items.find(item => item.product.id === product.id);
    
    if (existingItem) {
      setFormData(prev => ({
        ...prev,
        items: prev.items.map(item =>
          item.product.id === product.id
            ? {
                ...item,
                quantity: item.quantity + quantity,
                subtotal: (item.quantity + quantity) * item.price
              }
            : item
        )
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        items: [
          ...prev.items,
          {
            product,
            quantity,
            price: product.price,
            subtotal: quantity * product.price
          }
        ]
      }));
    }
    setSearchTerm('');
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setFormData(prev => ({
      ...prev,
      items: prev.items.map(item =>
        item.product.id === productId
          ? {
              ...item,
              quantity: newQuantity,
              subtotal: newQuantity * item.price
            }
          : item
      )
    }));
  };

  const handleRemoveItem = (productId: string) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter(item => item.product.id !== productId)
    }));
  };

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    
    setValidatingCoupon(true);
    setCouponError('');
    
    try {
      const result = await validateCoupon(couponCode, subtotal, formData.items);
      
      if (result.isValid) {
        setFormData(prev => ({
          ...prev,
          discount: result.discount,
          coupon: {
            code: couponCode.toUpperCase(),
            discount: result.discount
          }
        }));
        setCouponCode('');
        toast.success('Coupon applied successfully');
      } else {
        setCouponError(result.error || 'Invalid coupon');
        toast.error(result.error || 'Invalid coupon');
      }
    } catch (error) {
      setCouponError('Failed to validate coupon');
      toast.error('Failed to validate coupon');
    } finally {
      setValidatingCoupon(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.billing.name || !formData.billing.phone || !formData.billing.address) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (formData.items.length === 0) {
      toast.error('Please add at least one item');
      return;
    }

    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Order Items */}
      <div className="neu-flat p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Order Items</h3>
        
        <div className="space-y-4">
          <div className="relative">
            <input
              type="text"
              className="neu-input w-full"
              placeholder="Search products..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            
            {searchTerm.trim() && (
              <div className="absolute z-10 w-full mt-2 bg-white neu-flat p-2 space-y-2">
                {filteredProducts.map(product => (
                  <div
                    key={product.id}
                    className="flex items-center justify-between p-2 hover:bg-gray-50 rounded cursor-pointer"
                    onClick={() => handleAddItem(product)}
                  >
                    <div className="flex items-center gap-3">
                      {product.coverImage && (
                        <img
                          src={product.coverImage}
                          alt={product.title}
                          className="w-12 h-12 object-cover rounded"
                        />
                      )}
                      <div>
                        <p className="font-medium">{product.title}</p>
                        <p className="text-sm text-gray-500">{product.author}</p>
                      </div>
                    </div>
                    <p className="font-medium">{formatPrice(product.price)}</p>
                  </div>
                ))}
                {filteredProducts.length === 0 && (
                  <p className="text-center text-gray-500 py-2">No products found</p>
                )}
              </div>
            )}
          </div>

          {formData.items.length > 0 ? (
            <div className="space-y-4">
              {formData.items.map(item => (
                <div key={item.product.id} className="flex justify-between items-center p-4 neu-pressed">
                  <div className="flex gap-4">
                    {item.product.coverImage && (
                      <img
                        src={item.product.coverImage}
                        alt={item.product.title}
                        className="w-16 h-16 object-cover rounded"
                      />
                    )}
                    <div>
                      <p className="font-medium">{item.product.title}</p>
                      <p className="text-sm text-gray-500">
                        {formatPrice(item.price)} × {item.quantity}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(item.product.id, item.quantity - 1)}
                        className="neu-button p-1 text-gray-600"
                      >
                        -
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button
                        type="button"
                        onClick={() => handleUpdateQuantity(item.product.id, item.quantity + 1)}
                        className="neu-button p-1 text-gray-600"
                      >
                        +
                      </button>
                    </div>
                    <p className="font-medium w-24 text-right">{formatPrice(item.subtotal)}</p>
                    <button
                      type="button"
                      onClick={() => handleRemoveItem(item.product.id)}
                      className="neu-button p-2 text-red-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

              <div className="border-t pt-4">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                {formData.discount > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Discount</span>
                    <span>-{formatPrice(formData.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-medium text-gray-900 border-t mt-2 pt-2">
                  <span>Total</span>
                  <span>{formatPrice(total)}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center text-gray-500 py-8">
              Search and add products to the order
            </div>
          )}
        </div>
      </div>

      {/* Billing Details */}
      <div className="neu-flat p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Billing Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Name <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              className="neu-input w-full"
              value={formData.billing.name}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, name: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Phone <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              required
              className="neu-input w-full"
              value={formData.billing.phone}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, phone: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input
              type="email"
              className="neu-input w-full"
              value={formData.billing.email}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, email: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Address <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              className="neu-input w-full"
              value={formData.billing.address}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, address: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">City</label>
            <input
              type="text"
              className="neu-input w-full"
              value={formData.billing.city}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, city: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">State</label>
            <input
              type="text"
              className="neu-input w-full"
              value={formData.billing.state}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, state: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Postal Code</label>
            <input
              type="text"
              className="neu-input w-full"
              value={formData.billing.postcode}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, postcode: e.target.value }
              }))}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
            <input
              type="text"
              className="neu-input w-full"
              value={formData.billing.country}
              onChange={e => setFormData(prev => ({
                ...prev,
                billing: { ...prev.billing, country: e.target.value }
              }))}
            />
          </div>
        </div>
      </div>

      {/* Coupon */}
      <div className="neu-flat p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Apply Coupon</h3>
        <div className="flex gap-4">
          <input
            type="text"
            className="neu-input flex-1 uppercase"
            value={couponCode}
            onChange={e => setCouponCode(e.target.value.toUpperCase())}
            placeholder="Enter coupon code"
            disabled={validatingCoupon}
          />
          <button
            type="button"
            onClick={handleApplyCoupon}
            className="neu-button px-4 py-2 text-blue-600"
            disabled={!couponCode.trim() || validatingCoupon}
          >
            {validatingCoupon ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
            ) : (
              'Apply'
            )}
          </button>
        </div>
        {couponError && (
          <p className="mt-2 text-sm text-red-600">{couponError}</p>
        )}
        {formData.coupon && (
          <div className="mt-2 p-2 bg-green-50 text-green-700 rounded-lg flex justify-between items-center">
            <span>Coupon {formData.coupon.code} applied</span>
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, coupon: undefined, discount: 0 }))}
              className="text-red-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Order Details */}
      <div className="neu-flat p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Order Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <select
              className="neu-input w-full"
              value={formData.status}
              onChange={e => setFormData(prev => ({ 
                ...prev, 
                status: e.target.value as OrderStatus 
              }))}
            >
              {Object.entries(ORDER_STATUSES).map(([status, { label }]) => (
                <option key={status} value={status}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
            <select
              className="neu-input w-full"
              value={formData.paymentMethod}
              onChange={e => setFormData(prev => ({ 
                ...prev, 
                paymentMethod: e.target.value 
              }))}
            >
              <option value="Cash on Delivery">Cash on Delivery</option>
              <option value="Bank Transfer">Bank Transfer</option>
              <option value="Mobile Banking">Mobile Banking</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div className="neu-flat p-4">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Order Notes</h3>
        <textarea
          className="neu-input w-full h-24"
          value={formData.notes.join('\n')}
          onChange={e => setFormData(prev => ({
            ...prev,
            notes: e.target.value.split('\n').filter(note => note.trim())
          }))}
          placeholder="Add any special notes or instructions..."
        />
      </div>

      {/* Submit Buttons */}
      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>{initialData ? 'Update' : 'Create'} Order</>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}