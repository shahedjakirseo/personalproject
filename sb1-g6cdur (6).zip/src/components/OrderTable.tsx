import React, { useState } from 'react';
import { format } from 'date-fns';
import { Edit2, Trash2, MessageSquare } from 'lucide-react';
import { Order, OrderStatus, ORDER_STATUSES } from '../types/order';
import Modal from './Modal';
import OrderDetails from './OrderDetails';

interface OrderTableProps {
  orders: Order[];
  onEdit: (order: Order) => void;
  onDelete: (order: Order) => void;
  onUpdateStatus: (orderId: string, status: OrderStatus) => void;
  onAddNote: (orderId: string, note: string) => void;
  loading: boolean;
  hasMore: boolean;
  onLoadMore: () => void;
}

const formatPrice = (amount: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
};

export default function OrderTable({ 
  orders, onEdit, onDelete, onUpdateStatus, onAddNote,
  loading, hasMore, onLoadMore 
}: OrderTableProps) {
  const [noteText, setNoteText] = useState('');
  const [activeNoteOrder, setActiveNoteOrder] = useState<string | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handleAddNote = (orderId: string) => {
    if (noteText.trim()) {
      onAddNote(orderId, noteText.trim());
      setNoteText('');
      setActiveNoteOrder(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto neu-flat">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Order
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Customer
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Total
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {orders.map((order) => (
              <React.Fragment key={order.id}>
                <tr className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="text-sm font-medium text-blue-600 hover:text-blue-800"
                    >
                      {order.orderNumber}
                    </button>
                    <div className="text-sm text-gray-500">
                      {order.items.length} items
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="text-left group"
                    >
                      <div className="text-sm text-gray-900 group-hover:text-blue-600">
                        {order.billing.name}
                      </div>
                      <div className="text-sm text-gray-500">{order.billing.email}</div>
                      <div className="text-sm text-gray-500">{order.billing.phone}</div>
                    </button>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={order.status}
                      onChange={(e) => onUpdateStatus(order.id, e.target.value as OrderStatus)}
                      className={`neu-input text-xs font-semibold ${ORDER_STATUSES[order.status].color}`}
                    >
                      {Object.entries(ORDER_STATUSES).map(([status, { label }]) => (
                        <option key={status} value={status}>
                          {label}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">
                      {formatPrice(order.total)}
                    </div>
                    <div className="text-xs text-gray-500">
                      Subtotal: {formatPrice(order.subtotal)}
                    </div>
                    {order.discount > 0 && (
                      <div className="text-xs text-red-500">
                        Discount: -{formatPrice(order.discount)}
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {format(order.createdAt, 'MMM dd, yyyy')}
                    <div className="text-xs text-gray-400">
                      {format(order.createdAt, 'HH:mm')}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setActiveNoteOrder(activeNoteOrder === order.id ? null : order.id)}
                        className="neu-button p-2 text-blue-600"
                        title="Add note"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onEdit(order)}
                        className="neu-button p-2 text-blue-600"
                        title="Edit order"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDelete(order)}
                        className="neu-button p-2 text-red-600"
                        title="Delete order"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
                {activeNoteOrder === order.id && (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 bg-gray-50">
                      <div className="space-y-4">
                        {order.notes && order.notes.length > 0 && (
                          <div className="space-y-2">
                            <h4 className="text-sm font-medium text-gray-900">Order Notes:</h4>
                            {order.notes.map((note, index) => (
                              <div key={index} className="neu-flat p-3 text-sm text-gray-600">
                                {note}
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={noteText}
                            onChange={(e) => setNoteText(e.target.value)}
                            placeholder="Add a note..."
                            className="neu-input flex-1"
                          />
                          <button
                            onClick={() => handleAddNote(order.id)}
                            className="neu-button px-4 py-2 text-blue-600"
                          >
                            Add Note
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>

      {hasMore && (
        <div className="flex justify-center mt-4">
          <button
            onClick={onLoadMore}
            className="neu-button px-4 py-2 text-blue-600"
            disabled={loading}
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
            ) : (
              'Load More'
            )}
          </button>
        </div>
      )}

      {/* Order Details Modal */}
      <Modal
        isOpen={!!selectedOrder}
        onClose={() => setSelectedOrder(null)}
        title="Order Details"
      >
        {selectedOrder && <OrderDetails order={selectedOrder} />}
      </Modal>
    </div>
  );
}