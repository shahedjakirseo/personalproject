import React from 'react';
import { Edit2, Trash2, Tag, Book, FileText } from 'lucide-react';
import { Product } from '../types/product';
import { format } from 'date-fns';

interface ProductCardProps {
  product: Product;
  onEdit: () => void;
  onDelete: () => void;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat('bn-BD', {
    style: 'currency',
    currency: 'BDT',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(price);
};

export default function ProductCard({ product, onEdit, onDelete }: ProductCardProps) {
  return (
    <div className="neu-flat p-6 space-y-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">{product.title}</h3>
          <p className="text-gray-600">{product.author}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={onEdit}
            className="neu-button p-2 text-blue-600"
            title="Edit"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={onDelete}
            className="neu-button p-2 text-red-600"
            title="Delete"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {product.coverImage && (
        <img
          src={product.coverImage}
          alt={product.title}
          className="w-full h-48 object-cover rounded-lg shadow-md"
        />
      )}

      <div className="flex flex-wrap gap-2">
        {product.category && (
          <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-gray-600">
            <Tag className="w-3 h-3" />
            {product.category.name}
          </div>
        )}
        <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-green-600">
          {formatPrice(product.price)}
        </div>
        <div className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-blue-600">
          <Book className="w-3 h-3" />
          {product.pageCount} pages
        </div>
        {product.pdfURL && (
          <a
            href={product.pdfURL}
            target="_blank"
            rel="noopener noreferrer"
            className="neu-button px-3 py-1 text-sm flex items-center gap-1 text-blue-600"
          >
            <FileText className="w-3 h-3" />
            View PDF
          </a>
        )}
      </div>

      <div className="space-y-2">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-500">ISBN:</span>
            <span className="ml-2 text-gray-700">{product.isbn}</span>
          </div>
          <div>
            <span className="text-gray-500">Language:</span>
            <span className="ml-2 text-gray-700">{product.language}</span>
          </div>
          <div>
            <span className="text-gray-500">Publisher:</span>
            <span className="ml-2 text-gray-700">{product.publisher}</span>
          </div>
          <div>
            <span className="text-gray-500">Edition:</span>
            <span className="ml-2 text-gray-700">{product.edition}</span>
          </div>
          <div>
            <span className="text-gray-500">Cover:</span>
            <span className="ml-2 text-gray-700">{product.coverType}</span>
          </div>
          <div>
            <span className="text-gray-500">Stock:</span>
            <span className="ml-2 text-gray-700">{product.stock} copies</span>
          </div>
        </div>

        <div className="text-sm">
          <span className="text-gray-500">Dimensions:</span>
          <span className="ml-2 text-gray-700">
            {product.dimensions.width} × {product.dimensions.height} × {product.dimensions.depth} {product.dimensions.unit}
          </span>
        </div>

        <div className="text-sm">
          <span className="text-gray-500">Weight:</span>
          <span className="ml-2 text-gray-700">
            {product.weight.value} {product.weight.unit}
          </span>
        </div>
      </div>

      <div className="text-sm text-gray-500">
        Added: {format(product.createdAt, 'MMM dd, yyyy')}
      </div>
    </div>
  );
}