import React, { useState } from 'react';
import { ProductFormData, Product, LANGUAGES, COVER_TYPES, DIMENSION_UNITS, WEIGHT_UNITS } from '../types/product';
import CategorySelect from './CategorySelect';
import FileUpload from './FileUpload';

interface ProductFormProps {
  onSubmit: (data: ProductFormData) => Promise<void>;
  initialData?: Product;
  onCancel: () => void;
}

export default function ProductForm({ onSubmit, initialData, onCancel }: ProductFormProps) {
  const [formData, setFormData] = useState<ProductFormData>({
    title: initialData?.title || '',
    author: initialData?.author || '',
    description: initialData?.description || '',
    price: initialData?.price || 0,
    coverImage: initialData?.coverImage || '',
    pdfURL: initialData?.pdfURL || '',
    isbn: initialData?.isbn || '',
    pageCount: initialData?.pageCount || 0,
    language: initialData?.language || LANGUAGES[0],
    publisher: initialData?.publisher || '',
    publishDate: initialData?.publishDate || '',
    edition: initialData?.edition || '',
    coverType: initialData?.coverType || COVER_TYPES[0],
    dimensions: initialData?.dimensions || {
      width: 0,
      height: 0,
      depth: 0,
      unit: 'cm'
    },
    weight: initialData?.weight || {
      value: 0,
      unit: 'g'
    },
    stock: initialData?.stock || 0,
    category: initialData?.category || null
  });
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({
    image: 0,
    pdf: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Title <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          required
          className="neu-input w-full"
          value={formData.title}
          onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Author</label>
        <input
          type="text"
          className="neu-input w-full"
          value={formData.author}
          onChange={e => setFormData(prev => ({ ...prev, author: e.target.value }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
        <CategorySelect
          selectedCategory={formData.category}
          onChange={category => setFormData(prev => ({ ...prev, category }))}
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Price (BDT)</label>
        <input
          type="number"
          min="0"
          step="1"
          className="neu-input w-full"
          value={formData.price}
          onChange={e => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">Cover Image</label>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <p className="text-sm text-gray-500 mb-2">Upload Image</p>
            <FileUpload
              accept={{
                'image/*': ['.png', '.jpg', '.jpeg', '.webp']
              }}
              path="product-images"
              value={formData.coverImage}
              onChange={url => setFormData(prev => ({ ...prev, coverImage: url }))}
              onProgress={progress => setUploadProgress(prev => ({ ...prev, image: progress }))}
            />
          </div>
          <div>
            <p className="text-sm text-gray-500 mb-2">Or Enter Image URL</p>
            <input
              type="url"
              className="neu-input w-full"
              value={formData.coverImage}
              onChange={e => setFormData(prev => ({ ...prev, coverImage: e.target.value }))}
              placeholder="https://example.com/image.jpg"
            />
          </div>
          {uploadProgress.image > 0 && uploadProgress.image < 100 && (
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress.image}%` }}
              />
            </div>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">PDF File</label>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <p className="text-sm text-gray-500 mb-2">Upload PDF</p>
            <FileUpload
              accept={{
                'application/pdf': ['.pdf']
              }}
              path="product-pdfs"
              value={formData.pdfURL}
              onChange={url => setFormData(prev => ({ ...prev, pdfURL: url }))}
              onProgress={progress => setUploadProgress(prev => ({ ...prev, pdf: progress }))}
              maxSize={20971520} // 20MB limit for PDFs
            />
          </div>
          <div>
            <p className="text-sm text-gray-500 mb-2">Or Enter PDF URL</p>
            <input
              type="url"
              className="neu-input w-full"
              value={formData.pdfURL}
              onChange={e => setFormData(prev => ({ ...prev, pdfURL: e.target.value }))}
              placeholder="https://example.com/document.pdf"
            />
          </div>
          {uploadProgress.pdf > 0 && uploadProgress.pdf < 100 && (
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress.pdf}%` }}
              />
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">ISBN</label>
          <input
            type="text"
            className="neu-input w-full"
            value={formData.isbn}
            onChange={e => setFormData(prev => ({ ...prev, isbn: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Page Count</label>
          <input
            type="number"
            min="0"
            className="neu-input w-full"
            value={formData.pageCount}
            onChange={e => setFormData(prev => ({ ...prev, pageCount: parseInt(e.target.value) || 0 }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>
          <select
            className="neu-input w-full"
            value={formData.language}
            onChange={e => setFormData(prev => ({ ...prev, language: e.target.value }))}
          >
            {LANGUAGES.map(lang => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Cover Type</label>
          <select
            className="neu-input w-full"
            value={formData.coverType}
            onChange={e => setFormData(prev => ({ ...prev, coverType: e.target.value as 'Hardcover' | 'Paperback' }))}
          >
            {COVER_TYPES.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Publisher</label>
          <input
            type="text"
            className="neu-input w-full"
            value={formData.publisher}
            onChange={e => setFormData(prev => ({ ...prev, publisher: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Edition</label>
          <input
            type="text"
            className="neu-input w-full"
            value={formData.edition}
            onChange={e => setFormData(prev => ({ ...prev, edition: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Publish Date</label>
          <input
            type="date"
            className="neu-input w-full"
            value={formData.publishDate}
            onChange={e => setFormData(prev => ({ ...prev, publishDate: e.target.value }))}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Stock</label>
          <input
            type="number"
            min="0"
            className="neu-input w-full"
            value={formData.stock}
            onChange={e => setFormData(prev => ({ ...prev, stock: parseInt(e.target.value) || 0 }))}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Dimensions</label>
        <div className="grid grid-cols-4 gap-2">
          <input
            type="number"
            min="0"
            step="0.1"
            placeholder="Width"
            className="neu-input"
            value={formData.dimensions.width}
            onChange={e => setFormData(prev => ({
              ...prev,
              dimensions: { ...prev.dimensions, width: parseFloat(e.target.value) || 0 }
            }))}
          />
          <input
            type="number"
            min="0"
            step="0.1"
            placeholder="Height"
            className="neu-input"
            value={formData.dimensions.height}
            onChange={e => setFormData(prev => ({
              ...prev,
              dimensions: { ...prev.dimensions, height: parseFloat(e.target.value) || 0 }
            }))}
          />
          <input
            type="number"
            min="0"
            step="0.1"
            placeholder="Depth"
            className="neu-input"
            value={formData.dimensions.depth}
            onChange={e => setFormData(prev => ({
              ...prev,
              dimensions: { ...prev.dimensions, depth: parseFloat(e.target.value) || 0 }
            }))}
          />
          <select
            className="neu-input"
            value={formData.dimensions.unit}
            onChange={e => setFormData(prev => ({
              ...prev,
              dimensions: { ...prev.dimensions, unit: e.target.value as 'cm' | 'inch' }
            }))}
          >
            {DIMENSION_UNITS.map(unit => (
              <option key={unit} value={unit}>{unit}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Weight</label>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            min="0"
            step="0.1"
            placeholder="Weight"
            className="neu-input"
            value={formData.weight.value}
            onChange={e => setFormData(prev => ({
              ...prev,
              weight: { ...prev.weight, value: parseFloat(e.target.value) || 0 }
            }))}
          />
          <select
            className="neu-input"
            value={formData.weight.unit}
            onChange={e => setFormData(prev => ({
              ...prev,
              weight: { ...prev.weight, unit: e.target.value as 'kg' | 'g' }
            }))}
          >
            {WEIGHT_UNITS.map(unit => (
              <option key={unit} value={unit}>{unit}</option>
            ))}
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
        <textarea
          className="neu-input w-full h-32"
          value={formData.description}
          onChange={e => setFormData(prev => ({ ...prev, description: e.target.value }))}
        />
      </div>

      <div className="flex gap-4">
        <button
          type="submit"
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2 flex-1"
          disabled={loading}
        >
          {loading ? (
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
          ) : (
            <>{initialData ? 'Update' : 'Create'} Product</>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="neu-button px-4 py-2 text-red-600"
          disabled={loading}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}