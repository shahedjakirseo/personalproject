import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  Users,
  ShoppingBag,
  FileText,
  GraduationCap,
  Ticket,
  ShoppingCart,
  Receipt,
  X
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface SidebarProps {
  isMobileOpen: boolean;
  setIsMobileOpen: (isOpen: boolean) => void;
}

export default function Sidebar({ isMobileOpen, setIsMobileOpen }: SidebarProps) {
  const { logout } = useAuth();

  const navItems = [
    { icon: LayoutDashboard, name: 'Dashboard', path: '/' },
    { icon: BookOpen, name: 'Books', path: '/books' },
    { icon: Users, name: 'Users', path: '/users' },
    { icon: ShoppingBag, name: 'Products', path: '/products' },
    { icon: FileText, name: 'Blogs', path: '/blogs' },
    { icon: GraduationCap, name: 'Courses', path: '/courses' },
    { icon: Ticket, name: 'Coupons', path: '/coupons' },
    { icon: ShoppingCart, name: 'Orders', path: '/orders' },
    { icon: Receipt, name: 'Invoices', path: '/invoices' },
  ];

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-20 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 z-30 h-full w-64 transform bg-[#EEF0F4] transition-transform duration-300 ease-in-out lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col">
          {/* Header */}
          <div className="flex h-16 items-center justify-between px-6">
            <h1 className="text-xl font-bold text-gray-800">Admin Panel</h1>
            <button
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden neu-button p-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 space-y-2 px-4 py-4">
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `flex items-center px-6 py-3 text-gray-700 transition-all duration-200 ${
                    isActive
                      ? 'neu-pressed text-blue-600'
                      : 'neu-flat hover:text-blue-600'
                  }`
                }
                onClick={() => setIsMobileOpen(false)}
              >
                <item.icon className="mr-4 h-5 w-5" />
                {item.name}
              </NavLink>
            ))}
          </nav>

          {/* Footer */}
          <div className="p-6">
            <button
              onClick={handleLogout}
              className="neu-button w-full px-4 py-3 text-red-600"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </>
  );
}