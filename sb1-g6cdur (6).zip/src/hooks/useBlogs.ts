import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Blog, BlogFormData } from '../types/blog';
import { useCategories } from './useCategories';
import toast from 'react-hot-toast';

const BLOGS_PER_PAGE = 20;
const STORAGE_KEY = 'blogManagementData';

export const useBlogs = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [displayedBlogs, setDisplayedBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { addCategory } = useCategories();

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setBlogs(parsedData);
          updateDisplayedBlogs(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading blogs:', error);
        setError('Failed to load blogs');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'blogs'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const blogsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date(),
        publishDate: doc.data().publishDate?.toDate() || null
      })) as Blog[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(blogsData));
      setBlogs(blogsData);
      updateDisplayedBlogs(blogsData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching blogs:', err);
      setError(err.message || 'Failed to fetch blogs');
      toast.error('Failed to load blogs. Please try again.');
    }
  };

  const addBlog = async (blogData: BlogFormData) => {
    try {
      const readTime = Math.ceil(blogData.content.split(/\s+/).length / 200);
      
      const newBlogData = {
        ...blogData,
        readTime,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        publishDate: blogData.publishDate ? Timestamp.fromDate(new Date(blogData.publishDate)) : null
      };

      const docRef = await addDoc(collection(db, 'blogs'), newBlogData);
      const newBlog = {
        id: docRef.id,
        ...newBlogData,
        createdAt: new Date(),
        updatedAt: new Date(),
        publishDate: blogData.publishDate ? new Date(blogData.publishDate) : null
      } as Blog;

      const updatedBlogs = [newBlog, ...blogs];
      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success('Blog post added successfully');
    } catch (error) {
      console.error('Error adding blog:', error);
      toast.error('Failed to add blog post');
      throw error;
    }
  };

  const updateBlog = async (blogId: string, blogData: BlogFormData) => {
    try {
      const readTime = Math.ceil(blogData.content.split(/\s+/).length / 200);
      
      const updateData = {
        ...blogData,
        readTime,
        updatedAt: serverTimestamp(),
        publishDate: blogData.publishDate ? Timestamp.fromDate(new Date(blogData.publishDate)) : null
      };

      await updateDoc(doc(db, 'blogs', blogId), updateData);

      const updatedBlogs = blogs.map(blog =>
        blog.id === blogId
          ? { 
              ...blog, 
              ...updateData, 
              updatedAt: new Date(),
              publishDate: blogData.publishDate ? new Date(blogData.publishDate) : null
            }
          : blog
      );

      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success('Blog post updated successfully');
    } catch (error) {
      console.error('Error updating blog:', error);
      toast.error('Failed to update blog post');
      throw error;
    }
  };

  const deleteBlog = async (blogId: string) => {
    try {
      await deleteDoc(doc(db, 'blogs', blogId));
      
      const updatedBlogs = blogs.filter(blog => blog.id !== blogId);
      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success('Blog post deleted successfully');
    } catch (error) {
      console.error('Error deleting blog:', error);
      toast.error('Failed to delete blog post');
      throw error;
    }
  };

  const toggleBlogStatus = async (blogId: string) => {
    const blog = blogs.find(b => b.id === blogId);
    if (!blog) return;

    const newStatus = blog.status === 'published' ? 'draft' : 'published';
    try {
      await updateDoc(doc(db, 'blogs', blogId), {
        status: newStatus,
        updatedAt: serverTimestamp()
      });

      const updatedBlogs = blogs.map(b =>
        b.id === blogId
          ? { ...b, status: newStatus, updatedAt: new Date() }
          : b
      );

      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success(`Blog post ${newStatus === 'published' ? 'published' : 'unpublished'}`);
    } catch (error) {
      console.error('Error toggling blog status:', error);
      toast.error('Failed to update blog status');
    }
  };

  const toggleBlogFeatured = async (blogId: string) => {
    const blog = blogs.find(b => b.id === blogId);
    if (!blog) return;

    try {
      await updateDoc(doc(db, 'blogs', blogId), {
        featured: !blog.featured,
        updatedAt: serverTimestamp()
      });

      const updatedBlogs = blogs.map(b =>
        b.id === blogId
          ? { ...b, featured: !b.featured, updatedAt: new Date() }
          : b
      );

      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success(`Blog post ${!blog.featured ? 'featured' : 'unfeatured'}`);
    } catch (error) {
      console.error('Error toggling blog featured status:', error);
      toast.error('Failed to update featured status');
    }
  };

  const updateDisplayedBlogs = (allBlogs: Blog[], page: number, category: string | null = null) => {
    let filteredBlogs = [...allBlogs];
    
    if (category) {
      filteredBlogs = filteredBlogs.filter(blog => blog.category?.id === category);
    }

    const start = (page - 1) * BLOGS_PER_PAGE;
    const end = start + BLOGS_PER_PAGE;
    const paginatedBlogs = filteredBlogs.slice(0, end);
    
    setDisplayedBlogs(paginatedBlogs);
    setHasMore(end < filteredBlogs.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedBlogs(blogs, currentPage + 1, selectedCategory);
  };

  const searchBlogs = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedBlogs(blogs, 1, selectedCategory);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredBlogs = blogs.filter(blog =>
      blog.title.toLowerCase().includes(searchTermLower) ||
      blog.content.toLowerCase().includes(searchTermLower) ||
      blog.excerpt.toLowerCase().includes(searchTermLower)
    );

    setDisplayedBlogs(filteredBlogs);
    setHasMore(false);
  };

  const filterByCategory = (categoryId: string | null) => {
    setSelectedCategory(categoryId);
    updateDisplayedBlogs(blogs, 1, categoryId);
  };

  const bulkAddBlogs = async (blogsData: BlogFormData[], onProgress: (progress: number) => void) => {
    const addedBlogs: Blog[] = [];
    const total = blogsData.length;
    let completed = 0;

    try {
      for (const blogData of blogsData) {
        let category = null;
        
        if (blogData.categoryName) {
          try {
            category = await addCategory(blogData.categoryName);
          } catch (error) {
            console.error('Category creation error:', error);
            toast.error(`Failed to create category for ${blogData.title}`);
          }
        }

        const readTime = Math.ceil(blogData.content.split(/\s+/).length / 200);
        
        const newBlogData = {
          ...blogData,
          category,
          readTime,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          publishDate: blogData.publishDate ? Timestamp.fromDate(new Date(blogData.publishDate)) : null
        };

        const docRef = await addDoc(collection(db, 'blogs'), newBlogData);
        addedBlogs.push({
          id: docRef.id,
          ...newBlogData,
          createdAt: new Date(),
          updatedAt: new Date(),
          publishDate: blogData.publishDate ? new Date(blogData.publishDate) : null
        } as Blog);

        completed++;
        onProgress((completed / total) * 100);
      }

      const updatedBlogs = [...addedBlogs, ...blogs];
      setBlogs(updatedBlogs);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBlogs));
      updateDisplayedBlogs(updatedBlogs, currentPage, selectedCategory);
      
      toast.success(`Successfully added ${addedBlogs.length} blog posts`);
    } catch (error: any) {
      console.error('Bulk upload error:', error);
      toast.error(error.message || 'Failed to upload blog posts');
      throw error;
    }
  };

  return {
    blogs: displayedBlogs,
    loading,
    error,
    hasMore,
    addBlog,
    updateBlog,
    deleteBlog,
    searchBlogs,
    loadMore,
    filterByCategory,
    toggleBlogStatus,
    toggleBlogFeatured,
    bulkAddBlogs
  };
};