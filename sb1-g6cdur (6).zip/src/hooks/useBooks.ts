import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, addDoc, updateDoc, 
  deleteDoc, doc, Timestamp, getDocs, where, limit, 
  startAfter, QueryDocumentSnapshot
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Book, BookFormData, BulkUploadData } from '../types/book';
import { useCategories } from './useCategories';
import toast from 'react-hot-toast';

const STORAGE_KEY = 'bookSummaryData';
const BOOKS_PER_PAGE = 20;

export const useBooks = () => {
  const [allBooks, setAllBooks] = useState<Book[]>([]);
  const [displayedBooks, setDisplayedBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { addCategory } = useCategories();

  // Load initial data from localStorage or fetch from Firebase
  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        // Try to get data from localStorage first
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setAllBooks(parsedData);
          updateDisplayedBooks(parsedData, 1);
          // Fetch fresh data in background
          fetchAndUpdateCache();
        } else {
          // If no cached data, fetch from Firebase
          await fetchAndUpdateCache();
        }
      } catch (error) {
        console.error('Error loading initial data:', error);
        setError('Failed to load books');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'books'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const booksData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date()
      })) as Book[];

      // Update localStorage
      localStorage.setItem(STORAGE_KEY, JSON.stringify(booksData));
      
      setAllBooks(booksData);
      updateDisplayedBooks(booksData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching books:', err);
      setError(err.message || 'Failed to fetch books');
      toast.error('Failed to load books. Please try again.');
    }
  };

  const updateDisplayedBooks = (books: Book[], page: number, category: string | null = null) => {
    let filteredBooks = [...books];
    
    // Apply category filter if selected
    if (category) {
      filteredBooks = filteredBooks.filter(book => book.category?.id === category);
    }

    const totalPages = Math.ceil(filteredBooks.length / BOOKS_PER_PAGE);
    const start = (page - 1) * BOOKS_PER_PAGE;
    const paginatedBooks = filteredBooks.slice(0, start + BOOKS_PER_PAGE);
    
    setDisplayedBooks(paginatedBooks);
    setHasMore(page < totalPages);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedBooks(allBooks, currentPage + 1, selectedCategory);
  };

  const filterByCategory = (categoryId: string | null) => {
    setSelectedCategory(categoryId);
    updateDisplayedBooks(allBooks, 1, categoryId);
  };

  const searchBooks = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedBooks(allBooks, 1, selectedCategory);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredBooks = allBooks.filter(book =>
      book.bookName.toLowerCase().includes(searchTermLower) ||
      book.authorName.toLowerCase().includes(searchTermLower)
    );

    setDisplayedBooks(filteredBooks);
    setHasMore(false);
  };

  const addBook = async (bookData: BookFormData) => {
    try {
      const newBookData = {
        ...bookData,
        bookNameLower: bookData.bookName.toLowerCase(),
        authorNameLower: bookData.authorName.toLowerCase(),
        userId: 'default-user',
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      };

      const docRef = await addDoc(collection(db, 'books'), newBookData);
      const newBook = {
        id: docRef.id,
        ...newBookData,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Book;

      const updatedBooks = [newBook, ...allBooks];
      setAllBooks(updatedBooks);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBooks));
      updateDisplayedBooks(updatedBooks, currentPage, selectedCategory);
      
      toast.success('Book added successfully');
    } catch (error: any) {
      console.error('Add book error:', error);
      toast.error(error.message || 'Failed to add book');
      throw error;
    }
  };

  const updateBook = async (bookId: string, bookData: BookFormData) => {
    try {
      const updateData = {
        ...bookData,
        bookNameLower: bookData.bookName.toLowerCase(),
        authorNameLower: bookData.authorName.toLowerCase(),
        updatedAt: Timestamp.now()
      };

      await updateDoc(doc(db, 'books', bookId), updateData);

      const updatedBooks = allBooks.map(book =>
        book.id === bookId
          ? { ...book, ...updateData, updatedAt: new Date() }
          : book
      );

      setAllBooks(updatedBooks);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBooks));
      updateDisplayedBooks(updatedBooks, currentPage, selectedCategory);

      toast.success('Book updated successfully');
    } catch (error: any) {
      console.error('Update book error:', error);
      toast.error(error.message || 'Failed to update book');
      throw error;
    }
  };

  const deleteBook = async (bookId: string) => {
    try {
      await deleteDoc(doc(db, 'books', bookId));
      
      const updatedBooks = allBooks.filter(book => book.id !== bookId);
      setAllBooks(updatedBooks);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBooks));
      updateDisplayedBooks(updatedBooks, currentPage, selectedCategory);
      
      toast.success('Book deleted successfully');
    } catch (error: any) {
      console.error('Delete book error:', error);
      toast.error(error.message || 'Failed to delete book');
      throw error;
    }
  };

  const bulkAddBooks = async (booksData: BulkUploadData[], onProgress: (progress: number) => void) => {
    const addedBooks: Book[] = [];
    const total = booksData.length;
    let completed = 0;

    try {
      for (const bookData of booksData) {
        let category = null;
        
        if (bookData.categoryName) {
          try {
            category = await addCategory(bookData.categoryName);
          } catch (error) {
            console.error('Category creation error:', error);
            toast.error(`Failed to create category for ${bookData.bookName}`);
          }
        }

        const newBookData = {
          bookName: bookData.bookName,
          authorName: bookData.authorName,
          longSummary: bookData.longSummary || '',
          audioURL: bookData.audioURL || '',
          pdfURL: bookData.pdfURL || '',
          coverImageURL: bookData.coverImageURL || '',
          bookNameLower: bookData.bookName.toLowerCase(),
          authorNameLower: bookData.authorName.toLowerCase(),
          userId: 'default-user',
          createdAt: Timestamp.now(),
          updatedAt: Timestamp.now(),
          category: category
        };

        const docRef = await addDoc(collection(db, 'books'), newBookData);
        addedBooks.push({
          id: docRef.id,
          ...newBookData,
          createdAt: new Date(),
          updatedAt: new Date()
        } as Book);

        completed++;
        onProgress((completed / total) * 100);
      }

      const updatedBooks = [...addedBooks, ...allBooks];
      setAllBooks(updatedBooks);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedBooks));
      updateDisplayedBooks(updatedBooks, currentPage, selectedCategory);
      
      toast.success(`Successfully added ${addedBooks.length} books`);
    } catch (error: any) {
      console.error('Bulk upload error:', error);
      toast.error(error.message || 'Failed to upload books');
      throw error;
    }
  };

  return {
    books: displayedBooks,
    loading,
    error,
    hasMore,
    addBook,
    updateBook,
    deleteBook,
    searchBooks,
    bulkAddBooks,
    loadMore,
    filterByCategory
  };
};