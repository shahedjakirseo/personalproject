import { useState, useEffect } from 'react';
import { collection, query, orderBy, getDocs, addDoc, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Category } from '../types/book';
import { getUniqueCategories, sortCategories } from '../utils/categoryUtils';
import toast from 'react-hot-toast';

const CATEGORIES_STORAGE_KEY = 'bookSummaryCategories';

export const useCategories = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        // Try to get categories from localStorage first
        const cachedCategories = localStorage.getItem(CATEGORIES_STORAGE_KEY);
        if (cachedCategories) {
          const parsedCategories = JSON.parse(cachedCategories);
          const uniqueCategories = getUniqueCategories(parsedCategories);
          setCategories(sortCategories(uniqueCategories));
          setLoading(false);
        }

        // Fetch fresh data from Firebase
        const q = query(collection(db, 'categories'), orderBy('nameLower'));
        const snapshot = await getDocs(q);
        
        const categoryData = snapshot.docs.map(doc => ({
          id: doc.id,
          name: doc.data().name,
        }));

        // Process and update categories
        const uniqueCategories = getUniqueCategories(categoryData);
        const sortedCategories = sortCategories(uniqueCategories);
        
        setCategories(sortedCategories);
        localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(sortedCategories));
      } catch (error) {
        console.error('Categories error:', error);
        toast.error('Failed to load categories');
        
        // If we have cached data, continue using it
        const cachedCategories = localStorage.getItem(CATEGORIES_STORAGE_KEY);
        if (cachedCategories) {
          const parsedCategories = JSON.parse(cachedCategories);
          const uniqueCategories = getUniqueCategories(parsedCategories);
          setCategories(sortCategories(uniqueCategories));
        }
      } finally {
        setLoading(false);
      }
    };

    loadCategories();
  }, []);

  const searchCategories = async (searchTerm: string) => {
    if (!searchTerm || searchTerm.length < 2) return [];

    const searchTermLower = searchTerm.toLowerCase();
    const matchingCategories = categories.filter(category => 
      category.name.toLowerCase().includes(searchTermLower)
    );

    return getUniqueCategories(matchingCategories).slice(0, 5);
  };

  const addCategory = async (name: string) => {
    try {
      const existingCategory = categories.find(
        cat => cat.name.toLowerCase() === name.toLowerCase()
      );
      
      if (existingCategory) {
        return existingCategory;
      }

      const nameLower = name.toLowerCase();
      const newCategoryData = { 
        name,
        nameLower,
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now()
      };

      const docRef = await addDoc(collection(db, 'categories'), newCategoryData);
      const newCategory = { id: docRef.id, name };
      
      const updatedCategories = sortCategories(
        getUniqueCategories([...categories, newCategory])
      );
      
      setCategories(updatedCategories);
      localStorage.setItem(CATEGORIES_STORAGE_KEY, JSON.stringify(updatedCategories));
      
      return newCategory;
    } catch (error: any) {
      console.error('Add category error:', error);
      toast.error('Failed to add category');
      throw error;
    }
  };

  return {
    categories,
    loading,
    searchCategories,
    addCategory,
  };
};