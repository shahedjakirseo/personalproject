import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Coupon } from '../types/coupon';
import { OrderItem } from '../types/order';

export const useCouponValidation = () => {
  const validateCoupon = async (
    code: string,
    subtotal: number,
    items: OrderItem[]
  ): Promise<{ isValid: boolean; discount: number; error?: string }> => {
    try {
      // Find the coupon
      const q = query(
        collection(db, 'coupon'),
        where('code', '==', code.toUpperCase())
      );
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        return { isValid: false, discount: 0, error: 'Invalid coupon code' };
      }

      const coupon = {
        id: snapshot.docs[0].id,
        ...snapshot.docs[0].data(),
        startDate: snapshot.docs[0].data().startDate?.toDate(),
        endDate: snapshot.docs[0].data().endDate?.toDate(),
        createdAt: snapshot.docs[0].data().createdAt?.toDate(),
        updatedAt: snapshot.docs[0].data().updatedAt?.toDate()
      } as Coupon;

      // Check if coupon is active
      if (!coupon.isActive) {
        return { isValid: false, discount: 0, error: 'Coupon is inactive' };
      }

      // Check dates
      const now = new Date();
      if (now < coupon.startDate) {
        return { isValid: false, discount: 0, error: 'Coupon is not yet active' };
      }
      if (coupon.endDate && now > coupon.endDate) {
        return { isValid: false, discount: 0, error: 'Coupon has expired' };
      }

      // Check usage limit
      if (coupon.usageLimit > 0 && coupon.usageCount >= coupon.usageLimit) {
        return { isValid: false, discount: 0, error: 'Coupon usage limit reached' };
      }

      // Check minimum purchase amount
      if (subtotal < coupon.minPurchaseAmount) {
        return { 
          isValid: false, 
          discount: 0, 
          error: `Minimum purchase amount is ${new Intl.NumberFormat('bn-BD', {
            style: 'currency',
            currency: 'BDT'
          }).format(coupon.minPurchaseAmount)}` 
        };
      }

      // Calculate discount
      let discount = 0;
      if (coupon.discountType === 'percentage') {
        discount = (subtotal * coupon.discountValue) / 100;
      } else {
        discount = coupon.discountValue;
      }

      // Apply max discount limit
      if (coupon.maxDiscountAmount > 0) {
        discount = Math.min(discount, coupon.maxDiscountAmount);
      }

      // Check if coupon is applicable to specific products
      if (coupon.applicableProducts) {
        const applicableProductIds = coupon.applicableProducts.map(p => p.id);
        const applicableItems = items.filter(item => 
          applicableProductIds.includes(item.product.id)
        );

        if (applicableItems.length === 0) {
          return { 
            isValid: false, 
            discount: 0, 
            error: 'Coupon is not applicable to any items in your cart' 
          };
        }

        // Recalculate discount based on applicable items only
        const applicableSubtotal = applicableItems.reduce(
          (sum, item) => sum + item.subtotal, 
          0
        );

        if (coupon.discountType === 'percentage') {
          discount = (applicableSubtotal * coupon.discountValue) / 100;
        }

        if (coupon.maxDiscountAmount > 0) {
          discount = Math.min(discount, coupon.maxDiscountAmount);
        }
      }

      return { isValid: true, discount };
    } catch (error) {
      console.error('Error validating coupon:', error);
      return { isValid: false, discount: 0, error: 'Failed to validate coupon' };
    }
  };

  return { validateCoupon };
};