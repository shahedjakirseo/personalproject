import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Coupon, CouponFormData } from '../types/coupon';
import toast from 'react-hot-toast';

const COUPONS_PER_PAGE = 20;
const STORAGE_KEY = 'couponManagementData';

export const useCoupons = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [displayedCoupons, setDisplayedCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setCoupons(parsedData);
          updateDisplayedCoupons(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading coupons:', error);
        setError('Failed to load coupons');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'coupon'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const couponsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        startDate: doc.data().startDate?.toDate() || new Date(),
        endDate: doc.data().endDate?.toDate() || null,
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date()
      })) as Coupon[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(couponsData));
      setCoupons(couponsData);
      updateDisplayedCoupons(couponsData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching coupons:', err);
      setError(err.message || 'Failed to fetch coupons');
      toast.error('Failed to load coupons. Please try again.');
    }
  };

  const addCoupon = async (couponData: CouponFormData) => {
    try {
      const newCouponData = {
        ...couponData,
        usageCount: 0,
        startDate: Timestamp.fromDate(new Date(couponData.startDate)),
        endDate: couponData.endDate ? Timestamp.fromDate(new Date(couponData.endDate)) : null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'coupon'), newCouponData);
      const newCoupon = {
        id: docRef.id,
        ...newCouponData,
        startDate: new Date(couponData.startDate),
        endDate: couponData.endDate ? new Date(couponData.endDate) : null,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Coupon;

      const updatedCoupons = [newCoupon, ...coupons];
      setCoupons(updatedCoupons);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCoupons));
      updateDisplayedCoupons(updatedCoupons, currentPage);
      
      toast.success('Coupon created successfully');
    } catch (error) {
      console.error('Error adding coupon:', error);
      toast.error('Failed to create coupon');
      throw error;
    }
  };

  const updateCoupon = async (couponId: string, couponData: CouponFormData) => {
    try {
      const updateData = {
        ...couponData,
        startDate: Timestamp.fromDate(new Date(couponData.startDate)),
        endDate: couponData.endDate ? Timestamp.fromDate(new Date(couponData.endDate)) : null,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, 'coupon', couponId), updateData);

      const updatedCoupons = coupons.map(coupon =>
        coupon.id === couponId
          ? {
              ...coupon,
              ...couponData,
              startDate: new Date(couponData.startDate),
              endDate: couponData.endDate ? new Date(couponData.endDate) : null,
              updatedAt: new Date()
            }
          : coupon
      );

      setCoupons(updatedCoupons);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCoupons));
      updateDisplayedCoupons(updatedCoupons, currentPage);
      
      toast.success('Coupon updated successfully');
    } catch (error) {
      console.error('Error updating coupon:', error);
      toast.error('Failed to update coupon');
      throw error;
    }
  };

  const deleteCoupon = async (couponId: string) => {
    try {
      await deleteDoc(doc(db, 'coupon', couponId));
      
      const updatedCoupons = coupons.filter(coupon => coupon.id !== couponId);
      setCoupons(updatedCoupons);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCoupons));
      updateDisplayedCoupons(updatedCoupons, currentPage);
      
      toast.success('Coupon deleted successfully');
    } catch (error) {
      console.error('Error deleting coupon:', error);
      toast.error('Failed to delete coupon');
      throw error;
    }
  };

  const toggleCouponStatus = async (couponId: string) => {
    const coupon = coupons.find(c => c.id === couponId);
    if (!coupon) return;

    try {
      await updateDoc(doc(db, 'coupon', couponId), {
        isActive: !coupon.isActive,
        updatedAt: serverTimestamp()
      });

      const updatedCoupons = coupons.map(c =>
        c.id === couponId
          ? { ...c, isActive: !c.isActive, updatedAt: new Date() }
          : c
      );

      setCoupons(updatedCoupons);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCoupons));
      updateDisplayedCoupons(updatedCoupons, currentPage);
      
      toast.success(`Coupon ${!coupon.isActive ? 'activated' : 'deactivated'}`);
    } catch (error) {
      console.error('Error toggling coupon status:', error);
      toast.error('Failed to update coupon status');
    }
  };

  const updateDisplayedCoupons = (allCoupons: Coupon[], page: number) => {
    const start = (page - 1) * COUPONS_PER_PAGE;
    const end = start + COUPONS_PER_PAGE;
    const paginatedCoupons = allCoupons.slice(0, end);
    
    setDisplayedCoupons(paginatedCoupons);
    setHasMore(end < allCoupons.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedCoupons(coupons, currentPage + 1);
  };

  const searchCoupons = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedCoupons(coupons, 1);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredCoupons = coupons.filter(coupon =>
      coupon.code.toLowerCase().includes(searchTermLower) ||
      coupon.description.toLowerCase().includes(searchTermLower)
    );

    setDisplayedCoupons(filteredCoupons);
    setHasMore(false);
  };

  return {
    coupons: displayedCoupons,
    loading,
    error,
    hasMore,
    addCoupon,
    updateCoupon,
    deleteCoupon,
    searchCoupons,
    loadMore,
    toggleCouponStatus
  };
};