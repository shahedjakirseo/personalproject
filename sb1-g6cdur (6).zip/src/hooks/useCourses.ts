import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Course, CourseFormData } from '../types/course';
import toast from 'react-hot-toast';
import { slugify } from '../utils/stringUtils';

const COURSES_PER_PAGE = 12;
const STORAGE_KEY = 'courseManagementData';

export const useCourses = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [displayedCourses, setDisplayedCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setCourses(parsedData);
          updateDisplayedCourses(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading courses:', error);
        setError('Failed to load courses');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'courses'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const coursesData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date()
      })) as Course[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(coursesData));
      setCourses(coursesData);
      updateDisplayedCourses(coursesData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching courses:', err);
      setError(err.message || 'Failed to fetch courses');
      toast.error('Failed to load courses. Please try again.');
    }
  };

  const addCourse = async (courseData: CourseFormData) => {
    try {
      const slug = slugify(courseData.title);
      const newCourseData = {
        ...courseData,
        slug,
        chapters: [],
        totalDuration: 0,
        totalLessons: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'courses'), newCourseData);
      const newCourse = {
        id: docRef.id,
        ...newCourseData,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Course;

      const updatedCourses = [newCourse, ...courses];
      setCourses(updatedCourses);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCourses));
      updateDisplayedCourses(updatedCourses, currentPage);
      
      toast.success('Course created successfully');
      return newCourse;
    } catch (error) {
      console.error('Error adding course:', error);
      toast.error('Failed to create course');
      throw error;
    }
  };

  const updateCourse = async (courseId: string, courseData: Partial<CourseFormData>) => {
    try {
      const updateData = {
        ...courseData,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, 'courses', courseId), updateData);

      const updatedCourses = courses.map(course =>
        course.id === courseId
          ? { ...course, ...courseData, updatedAt: new Date() }
          : course
      );

      setCourses(updatedCourses);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCourses));
      updateDisplayedCourses(updatedCourses, currentPage);
      
      toast.success('Course updated successfully');
    } catch (error) {
      console.error('Error updating course:', error);
      toast.error('Failed to update course');
      throw error;
    }
  };

  const deleteCourse = async (courseId: string) => {
    try {
      await deleteDoc(doc(db, 'courses', courseId));
      
      const updatedCourses = courses.filter(course => course.id !== courseId);
      setCourses(updatedCourses);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedCourses));
      updateDisplayedCourses(updatedCourses, currentPage);
      
      toast.success('Course deleted successfully');
    } catch (error) {
      console.error('Error deleting course:', error);
      toast.error('Failed to delete course');
      throw error;
    }
  };

  const updateDisplayedCourses = (allCourses: Course[], page: number) => {
    const start = (page - 1) * COURSES_PER_PAGE;
    const end = start + COURSES_PER_PAGE;
    const paginatedCourses = allCourses.slice(0, end);
    
    setDisplayedCourses(paginatedCourses);
    setHasMore(end < allCourses.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedCourses(courses, currentPage + 1);
  };

  const searchCourses = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedCourses(courses, 1);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredCourses = courses.filter(course =>
      course.title.toLowerCase().includes(searchTermLower) ||
      course.shortDescription.toLowerCase().includes(searchTermLower) ||
      course.instructor.name.toLowerCase().includes(searchTermLower)
    );

    setDisplayedCourses(filteredCourses);
    setHasMore(false);
  };

  return {
    courses: displayedCourses,
    loading,
    error,
    hasMore,
    addCourse,
    updateCourse,
    deleteCourse,
    searchCourses,
    loadMore
  };
};