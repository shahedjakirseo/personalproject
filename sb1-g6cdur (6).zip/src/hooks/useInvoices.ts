import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Invoice, InvoiceFormData } from '../types/invoice';
import { Order } from '../types/order';
import toast from 'react-hot-toast';

const INVOICES_PER_PAGE = 20;
const STORAGE_KEY = 'invoiceManagementData';

export const useInvoices = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [displayedInvoices, setDisplayedInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setInvoices(parsedData);
          updateDisplayedInvoices(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading invoices:', error);
        setError('Failed to load invoices');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'invoice'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const invoicesData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date(),
        paymentDate: doc.data().paymentDate?.toDate() || null
      })) as Invoice[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(invoicesData));
      setInvoices(invoicesData);
      updateDisplayedInvoices(invoicesData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching invoices:', err);
      setError(err.message || 'Failed to fetch invoices');
      toast.error('Failed to load invoices. Please try again.');
    }
  };

  const generateInvoice = async (order: Order) => {
    try {
      const timestamp = Date.now();
      const invoiceNumber = `INV${timestamp}`;
      const invoiceData = {
        orderNumber: order.orderNumber,
        order,
        invoiceNumber,
        status: 'unpaid',
        paymentMethod: order.paymentMethod,
        paymentDate: null,
        billingDetails: order.billing,
        items: order.items.map(item => ({
          description: item.product.title,
          quantity: item.quantity,
          price: item.price,
          subtotal: item.subtotal
        })),
        subtotal: order.subtotal,
        discount: order.discount || 0,
        total: order.total,
        notes: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'invoice'), invoiceData);
      const newInvoice = {
        id: docRef.id,
        ...invoiceData,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Invoice;

      const updatedInvoices = [newInvoice, ...invoices];
      setInvoices(updatedInvoices);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedInvoices));
      updateDisplayedInvoices(updatedInvoices, currentPage);
      
      toast.success('Invoice generated successfully');
      return newInvoice;
    } catch (error) {
      console.error('Error generating invoice:', error);
      toast.error('Failed to generate invoice');
      throw error;
    }
  };

  const updateInvoice = async (invoiceId: string, invoiceData: InvoiceFormData) => {
    try {
      const updateData = {
        ...invoiceData,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, 'invoice', invoiceId), updateData);

      const updatedInvoices = invoices.map(invoice =>
        invoice.id === invoiceId
          ? { ...invoice, ...updateData, updatedAt: new Date() }
          : invoice
      );

      setInvoices(updatedInvoices);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedInvoices));
      updateDisplayedInvoices(updatedInvoices, currentPage);
      
      toast.success('Invoice updated successfully');
    } catch (error) {
      console.error('Error updating invoice:', error);
      toast.error('Failed to update invoice');
      throw error;
    }
  };

  const deleteInvoice = async (invoiceId: string) => {
    try {
      await deleteDoc(doc(db, 'invoice', invoiceId));
      
      const updatedInvoices = invoices.filter(invoice => invoice.id !== invoiceId);
      setInvoices(updatedInvoices);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedInvoices));
      updateDisplayedInvoices(updatedInvoices, currentPage);
      
      toast.success('Invoice deleted successfully');
    } catch (error) {
      console.error('Error deleting invoice:', error);
      toast.error('Failed to delete invoice');
      throw error;
    }
  };

  const updateDisplayedInvoices = (allInvoices: Invoice[], page: number) => {
    const start = (page - 1) * INVOICES_PER_PAGE;
    const end = start + INVOICES_PER_PAGE;
    const paginatedInvoices = allInvoices.slice(0, end);
    
    setDisplayedInvoices(paginatedInvoices);
    setHasMore(end < allInvoices.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedInvoices(invoices, currentPage + 1);
  };

  const searchInvoices = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedInvoices(invoices, 1);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredInvoices = invoices.filter(invoice =>
      invoice.invoiceNumber.toLowerCase().includes(searchTermLower) ||
      invoice.orderNumber.toLowerCase().includes(searchTermLower) ||
      invoice.billingDetails.name.toLowerCase().includes(searchTermLower)
    );

    setDisplayedInvoices(filteredInvoices);
    setHasMore(false);
  };

  return {
    invoices: displayedInvoices,
    loading,
    error,
    hasMore,
    generateInvoice,
    updateInvoice,
    deleteInvoice,
    searchInvoices,
    loadMore
  };
};