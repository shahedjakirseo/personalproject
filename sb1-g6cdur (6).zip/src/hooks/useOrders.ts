import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, serverTimestamp 
} from 'firebase/firestore';
import { db, collections } from '../lib/firebase';
import { Order, OrderFormData, OrderStatus } from '../types/order';
import { useCouponValidation } from './useCouponValidation';
import { useInvoices } from './useInvoices';
import toast from 'react-hot-toast';

const ORDERS_PER_PAGE = 20;
const STORAGE_KEY = 'orderManagementData';

export const useOrders = () => {
  const { validateCoupon: validateCouponInternal } = useCouponValidation();
  const { generateInvoice } = useInvoices();
  const [orders, setOrders] = useState<Order[]>([]);
  const [displayedOrders, setDisplayedOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<OrderStatus | null>(null);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setOrders(parsedData);
          updateDisplayedOrders(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading orders:', error);
        setError('Failed to load orders');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, collections.orders),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const ordersData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date()
      })) as Order[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(ordersData));
      setOrders(ordersData);
      updateDisplayedOrders(ordersData, 1, selectedStatus);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching orders:', err);
      setError(err.message || 'Failed to fetch orders');
      toast.error('Failed to load orders. Please try again.');
    }
  };

  const addOrder = async (orderData: OrderFormData) => {
    try {
      const orderNumber = `ORD${Date.now()}`;
      const subtotal = orderData.items.reduce((sum, item) => sum + item.subtotal, 0);
      const total = subtotal - (orderData.discount || 0);

      const newOrderData = {
        ...orderData,
        orderNumber,
        subtotal,
        total,
        tax: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, collections.orders), newOrderData);
      const newOrder = {
        id: docRef.id,
        ...newOrderData,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Order;

      // Generate invoice for the new order
      await generateInvoice(newOrder);

      const updatedOrders = [newOrder, ...orders];
      setOrders(updatedOrders);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
      updateDisplayedOrders(updatedOrders, currentPage, selectedStatus);
      
      toast.success('Order created successfully');
    } catch (error) {
      console.error('Error adding order:', error);
      toast.error('Failed to create order');
      throw error;
    }
  };

  const updateOrder = async (orderId: string, orderData: OrderFormData) => {
    try {
      const subtotal = orderData.items.reduce((sum, item) => sum + item.subtotal, 0);
      const total = subtotal - (orderData.discount || 0);

      const updateData = {
        ...orderData,
        subtotal,
        total,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, collections.orders, orderId), updateData);

      const updatedOrder = {
        id: orderId,
        ...updateData,
        updatedAt: new Date()
      } as Order;

      // Generate new invoice for the updated order
      await generateInvoice(updatedOrder);

      const updatedOrders = orders.map(order =>
        order.id === orderId
          ? updatedOrder
          : order
      );

      setOrders(updatedOrders);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
      updateDisplayedOrders(updatedOrders, currentPage, selectedStatus);
      
      toast.success('Order updated successfully');
    } catch (error) {
      console.error('Error updating order:', error);
      toast.error('Failed to update order');
      throw error;
    }
  };

  const deleteOrder = async (orderId: string) => {
    try {
      await deleteDoc(doc(db, collections.orders, orderId));
      
      const updatedOrders = orders.filter(order => order.id !== orderId);
      setOrders(updatedOrders);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
      updateDisplayedOrders(updatedOrders, currentPage, selectedStatus);
      
      toast.success('Order deleted successfully');
    } catch (error) {
      console.error('Error deleting order:', error);
      toast.error('Failed to delete order');
      throw error;
    }
  };

  const updateOrderStatus = async (orderId: string, status: OrderStatus) => {
    try {
      await updateDoc(doc(db, collections.orders, orderId), {
        status,
        updatedAt: serverTimestamp()
      });

      const updatedOrders = orders.map(order =>
        order.id === orderId
          ? { ...order, status, updatedAt: new Date() }
          : order
      );

      setOrders(updatedOrders);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
      updateDisplayedOrders(updatedOrders, currentPage, selectedStatus);
      
      toast.success('Order status updated successfully');
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Failed to update order status');
    }
  };

  const addOrderNote = async (orderId: string, note: string) => {
    try {
      const order = orders.find(o => o.id === orderId);
      if (!order) return;

      const updatedNotes = [...(order.notes || []), note];
      
      await updateDoc(doc(db, collections.orders, orderId), {
        notes: updatedNotes,
        updatedAt: serverTimestamp()
      });

      const updatedOrders = orders.map(o =>
        o.id === orderId
          ? { ...o, notes: updatedNotes, updatedAt: new Date() }
          : o
      );

      setOrders(updatedOrders);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
      updateDisplayedOrders(updatedOrders, currentPage, selectedStatus);
      
      toast.success('Note added successfully');
    } catch (error) {
      console.error('Error adding note:', error);
      toast.error('Failed to add note');
    }
  };

  const updateDisplayedOrders = (allOrders: Order[], page: number, status: OrderStatus | null = null) => {
    let filteredOrders = [...allOrders];
    
    if (status) {
      filteredOrders = filteredOrders.filter(order => order.status === status);
    }

    const start = (page - 1) * ORDERS_PER_PAGE;
    const end = start + ORDERS_PER_PAGE;
    const paginatedOrders = filteredOrders.slice(0, end);
    
    setDisplayedOrders(paginatedOrders);
    setHasMore(end < filteredOrders.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedOrders(orders, currentPage + 1, selectedStatus);
  };

  const searchOrders = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedOrders(orders, 1, selectedStatus);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredOrders = orders.filter(order =>
      order.orderNumber.toLowerCase().includes(searchTermLower) ||
      order.billing.name.toLowerCase().includes(searchTermLower) ||
      order.billing.email?.toLowerCase().includes(searchTermLower) ||
      order.billing.phone.includes(searchTermLower)
    );

    setDisplayedOrders(filteredOrders);
    setHasMore(false);
  };

  const filterByStatus = (status: OrderStatus | null) => {
    setSelectedStatus(status);
    updateDisplayedOrders(orders, 1, status);
  };

  const validateCoupon = async (code: string, subtotal: number, items: any[]) => {
    try {
      const result = await validateCouponInternal(code, subtotal, items);
      return result;
    } catch (error) {
      console.error('Error validating coupon:', error);
      return { isValid: false, discount: 0, error: 'Failed to validate coupon' };
    }
  };

  return {
    orders: displayedOrders,
    loading,
    error,
    hasMore,
    addOrder,
    updateOrder,
    deleteOrder,
    searchOrders,
    loadMore,
    filterByStatus,
    updateOrderStatus,
    addOrderNote,
    validateCoupon
  };
};