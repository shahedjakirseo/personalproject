import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Product, ProductFormData } from '../types/product';
import { useCategories } from './useCategories';
import toast from 'react-hot-toast';

const PRODUCTS_PER_PAGE = 20;
const STORAGE_KEY = 'productManagementData';

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [displayedProducts, setDisplayedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { addCategory } = useCategories();

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setProducts(parsedData);
          updateDisplayedProducts(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading products:', error);
        setError('Failed to load products');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'products'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const productsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate() || new Date(),
        updatedAt: doc.data().updatedAt?.toDate() || new Date()
      })) as Product[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(productsData));
      setProducts(productsData);
      updateDisplayedProducts(productsData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching products:', err);
      setError(err.message || 'Failed to fetch products');
      toast.error('Failed to load products. Please try again.');
    }
  };

  const addProduct = async (productData: ProductFormData) => {
    try {
      const newProductData = {
        ...productData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'products'), newProductData);
      const newProduct = {
        id: docRef.id,
        ...newProductData,
        createdAt: new Date(),
        updatedAt: new Date()
      } as Product;

      const updatedProducts = [newProduct, ...products];
      setProducts(updatedProducts);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
      updateDisplayedProducts(updatedProducts, currentPage, selectedCategory);
      
      toast.success('Product added successfully');
    } catch (error) {
      console.error('Error adding product:', error);
      toast.error('Failed to add product');
      throw error;
    }
  };

  const updateProduct = async (productId: string, productData: ProductFormData) => {
    try {
      const updateData = {
        ...productData,
        updatedAt: serverTimestamp()
      };

      await updateDoc(doc(db, 'products', productId), updateData);

      const updatedProducts = products.map(product =>
        product.id === productId
          ? { ...product, ...updateData, updatedAt: new Date() }
          : product
      );

      setProducts(updatedProducts);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
      updateDisplayedProducts(updatedProducts, currentPage, selectedCategory);
      
      toast.success('Product updated successfully');
    } catch (error) {
      console.error('Error updating product:', error);
      toast.error('Failed to update product');
      throw error;
    }
  };

  const deleteProduct = async (productId: string) => {
    try {
      await deleteDoc(doc(db, 'products', productId));
      
      const updatedProducts = products.filter(product => product.id !== productId);
      setProducts(updatedProducts);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedProducts));
      updateDisplayedProducts(updatedProducts, currentPage, selectedCategory);
      
      toast.success('Product deleted successfully');
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
      throw error;
    }
  };

  const updateDisplayedProducts = (allProducts: Product[], page: number, category: string | null = null) => {
    let filteredProducts = [...allProducts];
    
    if (category) {
      filteredProducts = filteredProducts.filter(product => product.category?.id === category);
    }

    const start = (page - 1) * PRODUCTS_PER_PAGE;
    const end = start + PRODUCTS_PER_PAGE;
    const paginatedProducts = filteredProducts.slice(0, end);
    
    setDisplayedProducts(paginatedProducts);
    setHasMore(end < filteredProducts.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedProducts(products, currentPage + 1, selectedCategory);
  };

  const searchProducts = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedProducts(products, 1, selectedCategory);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredProducts = products.filter(product =>
      product.title.toLowerCase().includes(searchTermLower) ||
      product.author.toLowerCase().includes(searchTermLower) ||
      product.isbn.toLowerCase().includes(searchTermLower)
    );

    setDisplayedProducts(filteredProducts);
    setHasMore(false);
  };

  const filterByCategory = (categoryId: string | null) => {
    setSelectedCategory(categoryId);
    updateDisplayedProducts(products, 1, categoryId);
  };

  return {
    products, // Return all products for selection in forms
    displayedProducts, // Return paginated/filtered products for display
    loading,
    error,
    hasMore,
    addProduct,
    updateProduct,
    deleteProduct,
    searchProducts,
    loadMore,
    filterByCategory
  };
};