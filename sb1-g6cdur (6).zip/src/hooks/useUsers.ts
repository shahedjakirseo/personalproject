import { useState, useEffect } from 'react';
import { 
  collection, query, orderBy, getDocs, doc, updateDoc, 
  deleteDoc, addDoc, Timestamp, serverTimestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserData } from '../types/user';
import toast from 'react-hot-toast';

const USERS_PER_PAGE = 10;
const STORAGE_KEY = 'userManagementData';

export const USER_ROLES = ['admin', 'editor', 'contributor', 'reader'] as const;

export const useUsers = () => {
  const [users, setUsers] = useState<UserData[]>([]);
  const [displayedUsers, setDisplayedUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    const loadInitialData = async () => {
      setLoading(true);
      try {
        const cachedData = localStorage.getItem(STORAGE_KEY);
        if (cachedData) {
          const parsedData = JSON.parse(cachedData);
          setUsers(parsedData);
          updateDisplayedUsers(parsedData, 1);
        }
        await fetchAndUpdateCache();
      } catch (error) {
        console.error('Error loading users:', error);
        setError('Failed to load users');
      } finally {
        setLoading(false);
      }
    };

    loadInitialData();
  }, []);

  const fetchAndUpdateCache = async () => {
    try {
      const q = query(
        collection(db, 'userdata'),
        orderBy('createdAt', 'desc')
      );

      const querySnapshot = await getDocs(q);
      const userData = querySnapshot.docs.map(doc => ({
        ...doc.data(),
      })) as UserData[];

      localStorage.setItem(STORAGE_KEY, JSON.stringify(userData));
      setUsers(userData);
      updateDisplayedUsers(userData, 1);
      setError(null);
    } catch (err: any) {
      console.error('Error fetching users:', err);
      setError(err.message || 'Failed to fetch users');
      toast.error('Failed to load users. Please try again.');
    }
  };

  const addUser = async (userData: Partial<UserData>) => {
    try {
      const newUser = {
        ...userData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'userdata'), newUser);
      const createdUser = {
        ...newUser,
        uid: docRef.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as UserData;

      const updatedUsers = [createdUser, ...users];
      setUsers(updatedUsers);
      updateDisplayedUsers(updatedUsers, currentPage);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUsers));
      
      toast.success('User created successfully');
    } catch (error) {
      console.error('Error creating user:', error);
      toast.error('Failed to create user');
      throw error;
    }
  };

  const updateUser = async (uid: string, userData: Partial<UserData>) => {
    try {
      const userRef = doc(db, 'userdata', uid);
      const updateData = {
        ...userData,
        updatedAt: serverTimestamp()
      };

      await updateDoc(userRef, updateData);

      const updatedUsers = users.map(user => 
        user.uid === uid ? { ...user, ...userData, updatedAt: new Date().toISOString() } : user
      );
      setUsers(updatedUsers);
      updateDisplayedUsers(updatedUsers, currentPage);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUsers));
      
      toast.success('User updated successfully');
    } catch (error) {
      console.error('Error updating user:', error);
      toast.error('Failed to update user');
      throw error;
    }
  };

  const deleteUser = async (uid: string) => {
    try {
      await deleteDoc(doc(db, 'userdata', uid));
      
      const updatedUsers = users.filter(user => user.uid !== uid);
      setUsers(updatedUsers);
      updateDisplayedUsers(updatedUsers, currentPage);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUsers));
      
      toast.success('User deleted successfully');
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error('Failed to delete user');
      throw error;
    }
  };

  const updateUserRole = async (uid: string, newRole: string) => {
    try {
      const userRef = doc(db, 'userdata', uid);
      await updateDoc(userRef, {
        role: newRole,
        updatedAt: serverTimestamp()
      });

      const updatedUsers = users.map(user => 
        user.uid === uid ? { ...user, role: newRole, updatedAt: new Date().toISOString() } : user
      );
      setUsers(updatedUsers);
      updateDisplayedUsers(updatedUsers, currentPage);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedUsers));
      
      toast.success('User role updated successfully');
    } catch (error) {
      console.error('Error updating user role:', error);
      toast.error('Failed to update user role');
      throw error;
    }
  };

  const updateDisplayedUsers = (allUsers: UserData[], page: number) => {
    const start = (page - 1) * USERS_PER_PAGE;
    const end = start + USERS_PER_PAGE;
    const paginatedUsers = allUsers.slice(0, end);
    
    setDisplayedUsers(paginatedUsers);
    setHasMore(end < allUsers.length);
    setCurrentPage(page);
  };

  const loadMore = () => {
    if (loading || !hasMore) return;
    updateDisplayedUsers(users, currentPage + 1);
  };

  const searchUsers = (searchTerm: string) => {
    if (!searchTerm.trim()) {
      updateDisplayedUsers(users, 1);
      return;
    }

    const searchTermLower = searchTerm.toLowerCase();
    const filteredUsers = users.filter(user =>
      user.name.toLowerCase().includes(searchTermLower) ||
      user.email.toLowerCase().includes(searchTermLower) ||
      user.phone.includes(searchTermLower)
    );

    setDisplayedUsers(filteredUsers);
    setHasMore(false);
  };

  return {
    users: displayedUsers,
    loading,
    error,
    hasMore,
    searchUsers,
    loadMore,
    updateUserRole,
    addUser,
    updateUser,
    deleteUser
  };
};