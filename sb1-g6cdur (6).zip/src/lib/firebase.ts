import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAapvLB9Y1ahMPXuL7nDoWzQOfzcncqqCM",
  authDomain: "audio-book-summary-16af8.firebaseapp.com",
  projectId: "audio-book-summary-16af8",
  storageBucket: "audio-book-summary-16af8.firebasestorage.app",
  messagingSenderId: "641502105663",
  appId: "1:641502105663:web:a0288c604f3e9731c3e88a",
  measurementId: "G-DVWE3C0RKR"
};

// Initialize Firebase services
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Collection names
export const collections = {
  blogs: 'blogs',
  books: 'books',
  categories: 'categories',
  coupons: 'coupon',
  orders: 'orderdata',
  products: 'products',
  users: 'userdata'
} as const;

// Utility function to get collection reference
export const getCollectionRef = (name: keyof typeof collections) => {
  return collection(db, collections[name]);
};