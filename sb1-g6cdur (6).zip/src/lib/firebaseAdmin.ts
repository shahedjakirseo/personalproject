import { db, auth } from './firebase';
import { collection, doc, setDoc, getDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { collections } from './firebase';

export const initializeFirebaseCollections = async () => {
  // Create default categories
  const defaultCategories = [
    { name: 'Self Help', nameLower: 'self help' },
    { name: 'Business', nameLower: 'business' },
    { name: 'Philosophy', nameLower: 'philosophy' },
    { name: 'Psychology', nameLower: 'psychology' },
    { name: 'Science', nameLower: 'science' }
  ];

  try {
    // Add default categories
    for (const category of defaultCategories) {
      const categoryRef = doc(collection(db, collections.categories));
      await setDoc(categoryRef, {
        ...category,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }

    // Create default admin user if it doesn't exist
    const adminEmail = 'admin@example.com';
    const adminPassword = 'admin123';

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, adminEmail, adminPassword);
      const userRef = doc(db, 'users', userCredential.user.uid);
      
      // Check if user document exists
      const userDoc = await getDoc(userRef);
      
      if (!userDoc.exists()) {
        // Create user document with admin role
        await setDoc(userRef, {
          email: adminEmail,
          role: 'admin',
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
    } catch (error: any) {
      // Ignore if user already exists
      if (error.code !== 'auth/email-already-in-use') {
        throw error;
      }
    }

    console.log('Firebase collections initialized successfully');
  } catch (error) {
    console.error('Error initializing Firebase collections:', error);
  }
};