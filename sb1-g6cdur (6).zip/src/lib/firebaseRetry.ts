import { FirebaseError } from 'firebase/app';

interface RetryConfig {
  maxAttempts?: number;
  initialDelay?: number;
  maxDelay?: number;
}

const defaultConfig: RetryConfig = {
  maxAttempts: 3,
  initialDelay: 1000,
  maxDelay: 5000
};

export const withRetry = async <T>(
  operation: () => Promise<T>,
  config: RetryConfig = {}
): Promise<T> => {
  const { maxAttempts, initialDelay, maxDelay } = { ...defaultConfig, ...config };
  let lastError: Error | null = null;
  let attempt = 0;

  while (attempt < maxAttempts) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      
      if (error instanceof FirebaseError) {
        // Don't retry on authentication or permission errors
        if (error.code.includes('auth/') || error.code.includes('permission-denied')) {
          throw error;
        }
      }

      attempt++;
      if (attempt === maxAttempts) break;

      // Calculate delay with exponential backoff
      const delay = Math.min(initialDelay * Math.pow(2, attempt - 1), maxDelay);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError;
};