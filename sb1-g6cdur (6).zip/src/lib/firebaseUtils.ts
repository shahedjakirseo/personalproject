import { collection, query, orderBy, getDocs, Timestamp } from 'firebase/firestore';
import { db } from './firebase';
import { Book, Category } from '../types/book';

const BOOKS_PER_PAGE = 20;

export const fetchBooks = async () => {
  const q = query(
    collection(db, 'books'),
    orderBy('createdAt', 'desc')
  );

  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate() || new Date(),
    updatedAt: doc.data().updatedAt?.toDate() || new Date()
  })) as Book[];
};

export const fetchCategories = async () => {
  const q = query(collection(db, 'categories'), orderBy('nameLower'));
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map(doc => ({
    id: doc.id,
    name: doc.data().name,
  })) as Category[];
};

export const paginateBooks = (
  books: Book[], 
  page: number, 
  categoryId: string | null = null
): { books: Book[], hasMore: boolean } => {
  let filteredBooks = [...books];
  
  if (categoryId) {
    filteredBooks = filteredBooks.filter(book => book.category?.id === categoryId);
  }

  const start = (page - 1) * BOOKS_PER_PAGE;
  const paginatedBooks = filteredBooks.slice(0, start + BOOKS_PER_PAGE);
  const hasMore = paginatedBooks.length < filteredBooks.length;

  return { books: paginatedBooks, hasMore };
};

export const searchBooks = (books: Book[], searchTerm: string): Book[] => {
  if (!searchTerm.trim()) return books;

  const searchTermLower = searchTerm.toLowerCase();
  return books.filter(book =>
    book.bookName.toLowerCase().includes(searchTermLower) ||
    book.authorName.toLowerCase().includes(searchTermLower)
  );
};

export const createTimestamp = () => Timestamp.now();

export const STORAGE_KEYS = {
  BOOKS: 'bookSummaryData',
  CATEGORIES: 'bookSummaryCategories'
};