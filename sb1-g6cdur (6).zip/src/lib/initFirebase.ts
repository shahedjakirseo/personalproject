import { db, auth } from './firebase';
import { doc, setDoc, getDoc, collection, getDocs, writeBatch } from 'firebase/firestore';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import toast from 'react-hot-toast';

const ADMIN_EMAIL = 'admin@bookadmin.com';
const ADMIN_PASSWORD = 'Admin@123';

const initializeDefaultCategories = async () => {
  const defaultCategories = [
    { name: 'Self Help', nameLower: 'self help' },
    { name: 'Business', nameLower: 'business' },
    { name: 'Philosophy', nameLower: 'philosophy' },
    { name: 'Psychology', nameLower: 'psychology' },
    { name: 'Science', nameLower: 'science' }
  ];

  try {
    const categoriesRef = collection(db, 'categories');
    const snapshot = await getDocs(categoriesRef);

    if (snapshot.empty) {
      const batch = writeBatch(db);
      
      for (const category of defaultCategories) {
        const docRef = doc(categoriesRef);
        batch.set(docRef, {
          ...category,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
      
      await batch.commit();
      console.log('Default categories created');
    }
  } catch (error) {
    console.error('Error creating default categories:', error);
    throw error;
  }
};

const ensureUserDocument = async (uid: string) => {
  const userRef = doc(db, 'users', uid);
  
  try {
    await setDoc(userRef, {
      email: ADMIN_EMAIL,
      role: 'admin',
      createdAt: new Date(),
      updatedAt: new Date()
    }, { merge: true });
    
    return true;
  } catch (error) {
    console.error('Error ensuring user document:', error);
    throw error;
  }
};

export const initializeAdminUser = async () => {
  try {
    let userCredential;
    
    try {
      // Try to create new user first
      userCredential = await createUserWithEmailAndPassword(auth, ADMIN_EMAIL, ADMIN_PASSWORD);
      console.log('New admin user created');
    } catch (createError: any) {
      if (createError.code === 'auth/email-already-in-use') {
        // If user exists, try to sign in
        userCredential = await signInWithEmailAndPassword(auth, ADMIN_EMAIL, ADMIN_PASSWORD);
        console.log('Existing admin user signed in');
      } else {
        throw createError;
      }
    }

    await ensureUserDocument(userCredential.user.uid);
    await initializeDefaultCategories();
    
    toast.success('Admin account initialized successfully');
    return { email: ADMIN_EMAIL, password: ADMIN_PASSWORD };
  } catch (error: any) {
    console.error('Error initializing admin:', error);
    toast.error('Failed to initialize admin account');
    throw error;
  }
};