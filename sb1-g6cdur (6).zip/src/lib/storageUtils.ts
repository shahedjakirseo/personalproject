import { Book, Category } from '../types/book';

export const saveToLocalStorage = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

export const getFromLocalStorage = <T>(key: string): T | null => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  } catch (error) {
    console.error('Error reading from localStorage:', error);
    return null;
  }
};

export const updateLocalBooks = (books: Book[]): void => {
  saveToLocalStorage('bookSummaryData', books);
};

export const updateLocalCategories = (categories: Category[]): void => {
  saveToLocalStorage('bookSummaryCategories', categories);
};