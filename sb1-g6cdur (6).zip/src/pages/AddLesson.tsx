import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { useCourses } from '../hooks/useCourses';
import LessonForm from '../components/LessonForm';
import { Lesson } from '../types/course';

export default function AddLesson() {
  const { courseId, chapterId } = useParams();
  const navigate = useNavigate();
  const { courses, updateCourse } = useCourses();

  const course = courses.find(c => c.id === courseId);
  const chapter = course?.chapters.find(ch => ch.id === chapterId);

  if (!course || !chapter) {
    return <div>Loading...</div>;
  }

  const handleAddLesson = async (lessonData: Omit<Lesson, 'id'>) => {
    const newLesson = {
      ...lessonData,
      id: `lesson_${Date.now()}`
    };

    const updatedChapters = course.chapters.map(ch =>
      ch.id === chapterId
        ? { ...ch, lessons: [...ch.lessons, newLesson] }
        : ch
    );

    await updateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons: course.totalLessons + 1,
      totalDuration: course.totalDuration + lessonData.duration
    });

    navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`)}
          className="neu-button p-2 text-gray-600"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Add New Lesson</h1>
          <p className="text-sm text-gray-500">
            {course.title} • {chapter.title}
          </p>
        </div>
      </div>

      <div className="neu-flat p-6">
        <LessonForm
          onSubmit={handleAddLesson}
          onCancel={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`)}
          lessonOrder={chapter.lessons.length + 1}
        />
      </div>
    </div>
  );
}