import React, { useState } from 'react';
import { FileText, PlusCircle, Upload } from 'lucide-react';
import { useBlogs } from '../hooks/useBlogs';
import { useCategories } from '../hooks/useCategories';
import BlogCard from '../components/BlogCard';
import BlogForm from '../components/BlogForm';
import BulkBlogUpload from '../components/BulkBlogUpload';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Blog } from '../types/blog';

export default function Blogs() {
  const { 
    blogs, loading, error, hasMore, addBlog, updateBlog, deleteBlog, 
    searchBlogs, loadMore, filterByCategory, toggleBlogStatus, 
    toggleBlogFeatured, bulkAddBlogs 
  } = useBlogs();
  const { categories } = useCategories();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [editingBlog, setEditingBlog] = useState<Blog | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingBlog, setDeletingBlog] = useState<Blog | null>(null);

  // Get unique categories
  const uniqueCategories = Array.from(
    new Set(categories.map(cat => cat.name))
  ).map(name => categories.find(cat => cat.name === name)!);

  const handleEdit = (blog: Blog) => {
    setEditingBlog(blog);
    setShowEditForm(true);
  };

  const handleDelete = (blog: Blog) => {
    setDeletingBlog(blog);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingBlog) {
      await deleteBlog(deletingBlog.id);
      setShowDeleteConfirm(false);
      setDeletingBlog(null);
    }
  };

  const handleBulkUpload = async (data: any[], onProgress: (progress: number) => void) => {
    try {
      await bulkAddBlogs(data, onProgress);
      setShowBulkUpload(false);
    } catch (error) {
      console.error('Bulk upload error:', error);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <FileText className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Blog Posts</h1>
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => setShowBulkUpload(true)}
            className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Bulk Upload
          </button>
          <button
            onClick={() => setShowAddForm(true)}
            className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            New Post
          </button>
        </div>
      </div>

      <div className="flex gap-4 flex-col md:flex-row">
        <div className="flex-1">
          <SearchBar onSearch={searchBlogs} />
        </div>
        <select
          onChange={(e) => filterByCategory(e.target.value || null)}
          className="neu-input md:w-48"
        >
          <option value="">All Categories</option>
          {uniqueCategories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </div>

      {loading && blogs.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : blogs.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No blog posts found.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {blogs.map(blog => (
              <BlogCard
                key={blog.id}
                blog={blog}
                onEdit={() => handleEdit(blog)}
                onDelete={() => handleDelete(blog)}
                onToggleStatus={() => toggleBlogStatus(blog.id)}
                onToggleFeatured={() => toggleBlogFeatured(blog.id)}
              />
            ))}
          </div>
          
          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Add Blog Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Add New Blog Post"
      >
        <BlogForm
          onSubmit={async (data) => {
            await addBlog(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Blog Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingBlog(null);
        }}
        title="Edit Blog Post"
      >
        <BlogForm
          initialData={editingBlog || undefined}
          onSubmit={async (data) => {
            if (editingBlog) {
              await updateBlog(editingBlog.id, data);
              setShowEditForm(false);
              setEditingBlog(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingBlog(null);
          }}
        />
      </Modal>

      {/* Bulk Upload Modal */}
      <Modal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
        title="Bulk Upload Blog Posts"
      >
        <BulkBlogUpload
          onUpload={handleBulkUpload}
          onClose={() => setShowBulkUpload(false)}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingBlog(null);
        }}
        title="Delete Blog Post"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete "{deletingBlog?.title}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingBlog(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}