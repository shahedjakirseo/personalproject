import React, { useState } from 'react';
import { PlusCircle, Upload } from 'lucide-react';
import { useBooks } from '../hooks/useBooks';
import { useCategories } from '../hooks/useCategories';
import BookCard from '../components/BookCard';
import BookForm from '../components/BookForm';
import BulkUpload from '../components/BulkUpload';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Book } from '../types/book';

export default function Books() {
  const { books, loading, error, addBook, updateBook, deleteBook, bulkAddBooks, searchBooks, loadMore, hasMore, filterByCategory } = useBooks();
  const { categories } = useCategories();
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  // Get unique categories by name
  const uniqueCategories = Array.from(
    new Set(categories.map(cat => cat.name))
  ).map(name => categories.find(cat => cat.name === name)!);

  const handleEdit = (book: Book) => {
    setEditingBook(book);
    setShowEditForm(true);
  };

  const handleEditSubmit = async (data: any) => {
    if (editingBook) {
      await updateBook(editingBook.id, data);
      setShowEditForm(false);
      setEditingBook(null);
    }
  };

  const handleBulkUpload = async (data: any[], onProgress: (progress: number) => void) => {
    try {
      await bulkAddBooks(data, onProgress);
      setShowBulkUpload(false);
    } catch (error) {
      console.error('Bulk upload error:', error);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900">Book Summaries</h1>
          <div className="flex gap-4">
            <button
              onClick={() => setShowBulkUpload(true)}
              className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Bulk Upload
            </button>
            <button
              onClick={() => setShowAddForm(true)}
              className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4" />
              Add Book
            </button>
          </div>
        </div>

        <div className="flex gap-4 flex-col md:flex-row">
          <div className="flex-1">
            <SearchBar onSearch={searchBooks} />
          </div>
          <select
            onChange={(e) => filterByCategory(e.target.value || null)}
            className="neu-input md:w-48"
          >
            <option value="">All Categories</option>
            {uniqueCategories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Add New Book"
      >
        <BookForm
          onSubmit={async (data) => {
            await addBook(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingBook(null);
        }}
        title="Edit Book"
      >
        <BookForm
          onSubmit={handleEditSubmit}
          initialData={editingBook || undefined}
          onCancel={() => {
            setShowEditForm(false);
            setEditingBook(null);
          }}
        />
      </Modal>

      <Modal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
        title="Bulk Upload Books"
      >
        <BulkUpload
          onUpload={handleBulkUpload}
          onClose={() => setShowBulkUpload(false)}
        />
      </Modal>

      {loading && books.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : books.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No books found.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {books.map(book => (
              <BookCard
                key={book.id}
                book={book}
                onEdit={() => handleEdit(book)}
                onDelete={async () => {
                  await deleteBook(book.id);
                }}
              />
            ))}
          </div>
          
          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}