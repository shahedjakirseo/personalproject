import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PlusCircle, Edit2, Trash2, ChevronLeft, Play, Lock } from 'lucide-react';
import { useCourses } from '../hooks/useCourses';
import { Course, Chapter, Lesson } from '../types/course';
import Modal from '../components/Modal';
import { formatDuration } from '../utils/stringUtils';

export default function ChapterLessons() {
  const { courseId, chapterId } = useParams();
  const navigate = useNavigate();
  const { courses, updateCourse } = useCourses();
  const [course, setCourse] = useState<Course | null>(null);
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<Lesson | null>(null);

  useEffect(() => {
    const currentCourse = courses.find(c => c.id === courseId);
    if (currentCourse) {
      setCourse(currentCourse);
      const currentChapter = currentCourse.chapters.find(ch => ch.id === chapterId);
      if (currentChapter) {
        setChapter(currentChapter);
      }
    }
  }, [courseId, chapterId, courses]);

  if (!course || !chapter) {
    return <div>Loading...</div>;
  }

  const handleDeleteLesson = async (lesson: Lesson) => {
    const updatedChapters = course.chapters.map(ch =>
      ch.id === chapter.id
        ? { ...ch, lessons: ch.lessons.filter(l => l.id !== lesson.id) }
        : ch
    );

    await updateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons: course.totalLessons - 1,
      totalDuration: course.totalDuration - lesson.duration
    });
    setShowDeleteConfirm(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate(`/courses/${courseId}/chapters`)}
            className="neu-button p-2 text-gray-600"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{chapter.title}</h1>
            <p className="text-sm text-gray-500">{course.title}</p>
          </div>
        </div>
        <button
          onClick={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons/add`)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Add Lesson
        </button>
      </div>

      <div className="space-y-4">
        {chapter.lessons.map((lesson, index) => (
          <div key={lesson.id} className="neu-flat p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-medium text-gray-900">
                    {index + 1}. {lesson.title}
                  </h3>
                  {lesson.isPreview && (
                    <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">
                      Preview
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-500">
                  {formatDuration(lesson.duration)}
                </p>
                <p className="text-sm text-gray-600 mt-1">{lesson.description}</p>
              </div>
              <div className="flex items-center gap-2">
                {lesson.videoURL && (
                  <Play className="w-4 h-4 text-green-600" />
                )}
                {!lesson.isPreview && (
                  <Lock className="w-4 h-4 text-gray-400" />
                )}
                <button
                  onClick={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons/${lesson.id}/edit`)}
                  className="neu-button p-2 text-blue-600"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(lesson)}
                  className="neu-button p-2 text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!showDeleteConfirm}
        onClose={() => setShowDeleteConfirm(null)}
        title="Delete Lesson"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete this lesson? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => showDeleteConfirm && handleDeleteLesson(showDeleteConfirm)}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => setShowDeleteConfirm(null)}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}