import React, { useState } from 'react';
import { Ticket, PlusCircle } from 'lucide-react';
import { useCoupons } from '../hooks/useCoupons';
import CouponCard from '../components/CouponCard';
import CouponForm from '../components/CouponForm';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Coupon } from '../types/coupon';

export default function Coupons() {
  const { 
    coupons, loading, error, hasMore, addCoupon, updateCoupon, 
    deleteCoupon, searchCoupons, loadMore, toggleCouponStatus 
  } = useCoupons();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingCoupon, setDeletingCoupon] = useState<Coupon | null>(null);

  const handleEdit = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setShowEditForm(true);
  };

  const handleDelete = (coupon: Coupon) => {
    setDeletingCoupon(coupon);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingCoupon) {
      await deleteCoupon(deletingCoupon.id);
      setShowDeleteConfirm(false);
      setDeletingCoupon(null);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Ticket className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Coupons</h1>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Create Coupon
        </button>
      </div>

      <div className="flex gap-4">
        <div className="flex-1">
          <SearchBar onSearch={searchCoupons} />
        </div>
      </div>

      {loading && coupons.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : coupons.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No coupons found.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {coupons.map(coupon => (
              <CouponCard
                key={coupon.id}
                coupon={coupon}
                onEdit={() => handleEdit(coupon)}
                onDelete={() => handleDelete(coupon)}
                onToggleStatus={() => toggleCouponStatus(coupon.id)}
              />
            ))}
          </div>
          
          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Add Coupon Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Create New Coupon"
      >
        <CouponForm
          onSubmit={async (data) => {
            await addCoupon(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Coupon Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingCoupon(null);
        }}
        title="Edit Coupon"
      >
        <CouponForm
          initialData={editingCoupon || undefined}
          onSubmit={async (data) => {
            if (editingCoupon) {
              await updateCoupon(editingCoupon.id, data);
              setShowEditForm(false);
              setEditingCoupon(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingCoupon(null);
          }}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingCoupon(null);
        }}
        title="Delete Coupon"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete coupon "{deletingCoupon?.code}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingCoupon(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}