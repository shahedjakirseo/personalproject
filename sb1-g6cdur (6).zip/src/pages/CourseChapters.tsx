import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PlusCircle, Edit2, Trash2, ChevronLeft } from 'lucide-react';
import { useCourses } from '../hooks/useCourses';
import { Course, Chapter } from '../types/course';
import ChapterForm from '../components/ChapterForm';
import Modal from '../components/Modal';
import { formatDuration } from '../utils/stringUtils';

export default function CourseChapters() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { courses, updateCourse } = useCourses();
  const [course, setCourse] = useState<Course | null>(null);
  const [showAddChapter, setShowAddChapter] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<Chapter | null>(null);

  useEffect(() => {
    const currentCourse = courses.find(c => c.id === courseId);
    if (currentCourse) {
      setCourse(currentCourse);
    }
  }, [courseId, courses]);

  if (!course) {
    return <div>Loading...</div>;
  }

  const handleAddChapter = async (chapterData: Omit<Chapter, 'id'>) => {
    const newChapter = {
      ...chapterData,
      id: `chapter_${Date.now()}`,
      lessons: []
    };

    const updatedChapters = [...course.chapters, newChapter];
    await updateCourse(course.id, { chapters: updatedChapters });
    setShowAddChapter(false);
  };

  const handleEditChapter = async (chapterData: Omit<Chapter, 'id'>) => {
    if (!editingChapter) return;

    const updatedChapters = course.chapters.map(chapter =>
      chapter.id === editingChapter.id
        ? { ...chapter, ...chapterData, lessons: chapter.lessons }
        : chapter
    );

    await updateCourse(course.id, { chapters: updatedChapters });
    setEditingChapter(null);
  };

  const handleDeleteChapter = async (chapter: Chapter) => {
    const updatedChapters = course.chapters.filter(c => c.id !== chapter.id);
    const totalLessons = course.totalLessons - chapter.lessons.length;
    const totalDuration = course.totalDuration - chapter.lessons.reduce((sum, lesson) => sum + lesson.duration, 0);

    await updateCourse(course.id, { 
      chapters: updatedChapters,
      totalLessons,
      totalDuration
    });
    setShowDeleteConfirm(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/courses')}
            className="neu-button p-2 text-gray-600"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{course.title}</h1>
            <p className="text-sm text-gray-500">Manage chapters</p>
          </div>
        </div>
        <button
          onClick={() => setShowAddChapter(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Add Chapter
        </button>
      </div>

      <div className="space-y-4">
        {course.chapters.map((chapter, index) => (
          <div key={chapter.id} className="neu-flat p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">
                  Chapter {index + 1}: {chapter.title}
                </h3>
                <p className="text-sm text-gray-500">
                  {chapter.lessons.length} lessons • {formatDuration(
                    chapter.lessons.reduce((sum, lesson) => sum + lesson.duration, 0)
                  )}
                </p>
                <p className="text-sm text-gray-600 mt-1">{chapter.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate(`/courses/${courseId}/chapters/${chapter.id}/lessons`)}
                  className="neu-button px-4 py-2 text-blue-600"
                >
                  View Lessons
                </button>
                <button
                  onClick={() => setEditingChapter(chapter)}
                  className="neu-button p-2 text-blue-600"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(chapter)}
                  className="neu-button p-2 text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Chapter Modal */}
      <Modal
        isOpen={showAddChapter}
        onClose={() => setShowAddChapter(false)}
        title="Add New Chapter"
      >
        <ChapterForm
          onSubmit={handleAddChapter}
          onCancel={() => setShowAddChapter(false)}
          chapterOrder={course.chapters.length + 1}
        />
      </Modal>

      {/* Edit Chapter Modal */}
      <Modal
        isOpen={!!editingChapter}
        onClose={() => setEditingChapter(null)}
        title="Edit Chapter"
      >
        <ChapterForm
          initialData={editingChapter || undefined}
          onSubmit={handleEditChapter}
          onCancel={() => setEditingChapter(null)}
          chapterOrder={editingChapter?.order || 0}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={!!showDeleteConfirm}
        onClose={() => setShowDeleteConfirm(null)}
        title="Delete Chapter"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete this chapter and all its lessons? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => showDeleteConfirm && handleDeleteChapter(showDeleteConfirm)}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => setShowDeleteConfirm(null)}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}