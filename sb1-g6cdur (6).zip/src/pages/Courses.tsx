import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, PlusCircle } from 'lucide-react';
import { useCourses } from '../hooks/useCourses';
import CourseCard from '../components/CourseCard';
import CourseForm from '../components/CourseForm';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Course } from '../types/course';

export default function Courses() {
  const navigate = useNavigate();
  const { 
    courses, loading, error, hasMore, addCourse, 
    updateCourse, deleteCourse, searchCourses, loadMore 
  } = useCourses();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingCourse, setDeletingCourse] = useState<Course | null>(null);

  const handleEdit = (course: Course) => {
    setEditingCourse(course);
    setShowEditForm(true);
  };

  const handleDelete = (course: Course) => {
    setDeletingCourse(course);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingCourse) {
      await deleteCourse(deletingCourse.id);
      setShowDeleteConfirm(false);
      setDeletingCourse(null);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BookOpen className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Courses</h1>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Create Course
        </button>
      </div>

      <div className="flex gap-4">
        <div className="flex-1">
          <SearchBar onSearch={searchCourses} />
        </div>
      </div>

      {loading && courses.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : courses.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No courses found.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map(course => (
              <CourseCard
                key={course.id}
                course={course}
                onEdit={() => handleEdit(course)}
                onDelete={() => handleDelete(course)}
                onClick={() => navigate(`/courses/${course.id}/chapters`)}
              />
            ))}
          </div>
          
          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Add Course Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Create New Course"
      >
        <CourseForm
          onSubmit={async (data) => {
            const newCourse = await addCourse(data);
            setShowAddForm(false);
            navigate(`/courses/${newCourse.id}/chapters`);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Course Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingCourse(null);
        }}
        title="Edit Course"
      >
        <CourseForm
          initialData={editingCourse || undefined}
          onSubmit={async (data) => {
            if (editingCourse) {
              await updateCourse(editingCourse.id, data);
              setShowEditForm(false);
              setEditingCourse(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingCourse(null);
          }}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingCourse(null);
        }}
        title="Delete Course"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete "{deletingCourse?.title}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingCourse(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}