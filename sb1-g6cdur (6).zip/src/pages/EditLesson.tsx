import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { useCourses } from '../hooks/useCourses';
import LessonForm from '../components/LessonForm';
import { Lesson } from '../types/course';

export default function EditLesson() {
  const { courseId, chapterId, lessonId } = useParams();
  const navigate = useNavigate();
  const { courses, updateCourse } = useCourses();

  const course = courses.find(c => c.id === courseId);
  const chapter = course?.chapters.find(ch => ch.id === chapterId);
  const lesson = chapter?.lessons.find(l => l.id === lessonId);

  if (!course || !chapter || !lesson) {
    return <div>Loading...</div>;
  }

  const handleEditLesson = async (lessonData: Omit<Lesson, 'id'>) => {
    const oldDuration = lesson.duration;
    const durationDiff = lessonData.duration - oldDuration;

    const updatedChapters = course.chapters.map(ch =>
      ch.id === chapterId
        ? {
            ...ch,
            lessons: ch.lessons.map(l =>
              l.id === lessonId
                ? { ...l, ...lessonData }
                : l
            )
          }
        : ch
    );

    await updateCourse(course.id, { 
      chapters: updatedChapters,
      totalDuration: course.totalDuration + durationDiff
    });

    navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`)}
          className="neu-button p-2 text-gray-600"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Edit Lesson</h1>
          <p className="text-sm text-gray-500">
            {course.title} • {chapter.title}
          </p>
        </div>
      </div>

      <div className="neu-flat p-6">
        <LessonForm
          initialData={lesson}
          onSubmit={handleEditLesson}
          onCancel={() => navigate(`/courses/${courseId}/chapters/${chapterId}/lessons`)}
          lessonOrder={lesson.order}
        />
      </div>
    </div>
  );
}