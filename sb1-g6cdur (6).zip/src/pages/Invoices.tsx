import React, { useState } from 'react';
import { Receipt, FileText, Printer } from 'lucide-react';
import { useInvoices } from '../hooks/useInvoices';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { format } from 'date-fns';
import { Invoice } from '../types/invoice';

export default function Invoices() {
  const { 
    invoices, loading, error, hasMore, searchInvoices, 
    loadMore, deleteInvoice 
  } = useInvoices();

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingInvoice, setDeletingInvoice] = useState<Invoice | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  const handleDelete = (invoice: Invoice) => {
    setDeletingInvoice(invoice);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingInvoice) {
      await deleteInvoice(deletingInvoice.id);
      setShowDeleteConfirm(false);
      setDeletingInvoice(null);
    }
  };

  const formatPrice = (amount: number) => {
    return new Intl.NumberFormat('bn-BD', {
      style: 'currency',
      currency: 'BDT',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow && selectedInvoice) {
      const invoiceHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="UTF-8">
            <title>Invoice #${selectedInvoice.invoiceNumber}</title>
            <style>
              @media print {
                @page { margin: 0.5cm; }
              }
              body { 
                font-family: system-ui, -apple-system, sans-serif; 
                line-height: 1.5;
                margin: 0;
                padding: 0;
              }
              .container { 
                max-width: 800px; 
                margin: 40px auto; 
                padding: 20px;
              }
              .header { 
                text-align: center; 
                margin-bottom: 40px;
                padding-bottom: 20px;
                border-bottom: 1px solid #eee;
              }
              .details { 
                margin-bottom: 20px;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
              }
              .details h2 {
                grid-column: 1 / -1;
                margin: 0 0 10px 0;
                color: #374151;
                font-size: 1.25rem;
              }
              .details p {
                margin: 0;
                color: #4B5563;
              }
              .table { 
                width: 100%; 
                border-collapse: collapse; 
                margin: 20px 0;
              }
              .table th, .table td { 
                padding: 12px; 
                border-bottom: 1px solid #eee; 
                text-align: left;
              }
              .table th {
                background-color: #F9FAFB;
                font-weight: 600;
                color: #374151;
              }
              .total { 
                text-align: right; 
                margin-top: 20px;
                padding-top: 20px;
                border-top: 1px solid #eee;
              }
              .total p {
                margin: 5px 0;
                color: #4B5563;
              }
              .total h3 {
                margin: 10px 0;
                color: #111827;
                font-size: 1.5rem;
              }
              @media print {
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1 style="margin: 0; color: #111827;">Invoice #${selectedInvoice.invoiceNumber}</h1>
                <p style="margin: 5px 0; color: #4B5563;">Order #${selectedInvoice.orderNumber}</p>
                <p style="margin: 5px 0; color: #4B5563;">
                  Date: ${format(selectedInvoice.createdAt, 'MMM dd, yyyy')}
                </p>
              </div>

              <div class="details">
                <h2>Billing Details</h2>
                <div>
                  <p style="font-weight: 600;">${selectedInvoice.billingDetails.name}</p>
                  <p>${selectedInvoice.billingDetails.email || ''}</p>
                  <p>${selectedInvoice.billingDetails.phone}</p>
                  <p>${selectedInvoice.billingDetails.address}</p>
                  <p>${[
                    selectedInvoice.billingDetails.city,
                    selectedInvoice.billingDetails.state,
                    selectedInvoice.billingDetails.postcode,
                    selectedInvoice.billingDetails.country
                  ].filter(Boolean).join(', ')}</p>
                </div>
                <div style="text-align: right;">
                  <p><strong>Payment Method:</strong> ${selectedInvoice.paymentMethod}</p>
                  <p><strong>Status:</strong> ${selectedInvoice.status}</p>
                </div>
              </div>

              <table class="table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  ${selectedInvoice.items.map(item => `
                    <tr>
                      <td>${item.description}</td>
                      <td>${item.quantity}</td>
                      <td>${formatPrice(item.price)}</td>
                      <td>${formatPrice(item.subtotal)}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>

              <div class="total">
                <p>Subtotal: ${formatPrice(selectedInvoice.subtotal)}</p>
                ${selectedInvoice.discount > 0 ? `
                  <p>Discount: -${formatPrice(selectedInvoice.discount)}</p>
                ` : ''}
                <h3>Total: ${formatPrice(selectedInvoice.total)}</h3>
              </div>
            </div>
          </body>
        </html>
      `;
      printWindow.document.write(invoiceHtml);
      printWindow.document.close();
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Receipt className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Invoices</h1>
        </div>
      </div>

      <div className="flex gap-4">
        <div className="flex-1">
          <SearchBar onSearch={searchInvoices} />
        </div>
      </div>

      {loading && invoices.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : invoices.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No invoices found.
        </div>
      ) : (
        <>
          <div className="overflow-x-auto neu-flat">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Invoice Number
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order Number
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => setSelectedInvoice(invoice)}
                        className="text-sm font-medium text-blue-600 hover:text-blue-800"
                      >
                        {invoice.invoiceNumber}
                      </button>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {invoice.orderNumber}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">
                        {invoice.billingDetails.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {invoice.billingDetails.email}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {formatPrice(invoice.total)}
                      </div>
                      {invoice.discount > 0 && (
                        <div className="text-xs text-red-500">
                          -{formatPrice(invoice.discount)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${invoice.status === 'paid' ? 'bg-green-100 text-green-800' : 
                          invoice.status === 'cancelled' ? 'bg-red-100 text-red-800' : 
                          'bg-yellow-100 text-yellow-800'}`}
                      >
                        {invoice.status.charAt(0).toUpperCase() + invoice.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {format(invoice.createdAt, 'MMM dd, yyyy')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex gap-4">
                        <button
                          onClick={() => setSelectedInvoice(invoice)}
                          className="text-blue-600 hover:text-blue-800"
                          title="View Invoice"
                        >
                          <FileText className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(invoice)}
                          className="text-red-600 hover:text-red-800"
                          title="Delete Invoice"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Invoice View Modal */}
      <Modal
        isOpen={!!selectedInvoice}
        onClose={() => setSelectedInvoice(null)}
        title={`Invoice #${selectedInvoice?.invoiceNumber}`}
      >
        {selectedInvoice && (
          <div className="space-y-6">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  Order #{selectedInvoice.orderNumber}
                </h3>
                <p className="text-sm text-gray-500">
                  {format(selectedInvoice.createdAt, 'MMM dd, yyyy')}
                </p>
              </div>
              <button
                onClick={handlePrint}
                className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                Print Invoice
              </button>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="neu-flat p-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Billing Details</h4>
                <div className="space-y-1 text-sm">
                  <p className="font-medium">{selectedInvoice.billingDetails.name}</p>
                  <p>{selectedInvoice.billingDetails.email}</p>
                  <p>{selectedInvoice.billingDetails.phone}</p>
                  <p>{selectedInvoice.billingDetails.address}</p>
                  <p>
                    {[
                      selectedInvoice.billingDetails.city,
                      selectedInvoice.billingDetails.state,
                      selectedInvoice.billingDetails.postcode,
                      selectedInvoice.billingDetails.country
                    ].filter(Boolean).join(', ')}
                  </p>
                </div>
              </div>

              <div className="neu-flat p-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Payment Details</h4>
                <div className="space-y-1 text-sm">
                  <p><span className="font-medium">Method:</span> {selectedInvoice.paymentMethod}</p>
                  <p><span className="font-medium">Status:</span> {selectedInvoice.status}</p>
                  {selectedInvoice.paymentDate && (
                    <p>
                      <span className="font-medium">Paid on:</span>{' '}
                      {format(selectedInvoice.paymentDate, 'MMM dd, yyyy')}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="neu-flat p-4">
              <h4 className="text-sm font-medium text-gray-900 mb-4">Items</h4>
              <div className="space-y-4">
                {selectedInvoice.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b">
                    <div>
                      <p className="font-medium">{item.description}</p>
                      <p className="text-sm text-gray-500">
                        {formatPrice(item.price)} × {item.quantity}
                      </p>
                    </div>
                    <p className="font-medium">{formatPrice(item.subtotal)}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>{formatPrice(selectedInvoice.subtotal)}</span>
                </div>
                {selectedInvoice.discount > 0 && (
                  <div className="flex justify-between text-sm text-red-600">
                    <span>Discount</span>
                    <span>-{formatPrice(selectedInvoice.discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-medium">
                  <span>Total</span>
                  <span>{formatPrice(selectedInvoice.total)}</span>
                </div>
              </div>
            </div>

            {selectedInvoice.notes && selectedInvoice.notes.length > 0 && (
              <div className="neu-flat p-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Notes</h4>
                <div className="space-y-2">
                  {selectedInvoice.notes.map((note, index) => (
                    <p key={index} className="text-sm text-gray-600">{note}</p>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingInvoice(null);
        }}
        title="Delete Invoice"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete invoice "{deletingInvoice?.invoiceNumber}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingInvoice(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}