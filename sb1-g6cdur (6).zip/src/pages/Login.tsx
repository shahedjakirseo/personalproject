import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BookOpen, Lock, Mail } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

export default function Login() {
  const [email, setEmail] = useState('admin@bookadmin.com');
  const [password, setPassword] = useState('Admin@123');
  const [isLoading, setIsLoading] = useState(false);
  const { login, user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      await login(email, password);
      navigate('/');
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error('Invalid email or password');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#EEF0F4] flex items-center justify-center p-6">
      <div className="neu-flat p-8 w-full max-w-md space-y-8">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 neu-flat flex items-center justify-center rounded-full">
            <BookOpen className="h-8 w-8 text-blue-600" />
          </div>
          <h2 className="mt-6 text-3xl font-bold text-gray-900">
            Book Summary Admin
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Sign in to manage your book summaries
          </p>
        </div>

        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label className="flex items-center mb-2 text-sm font-medium text-gray-700">
                <Mail className="w-4 h-4 mr-2" />
                Email
              </label>
              <input
                type="email"
                required
                className="neu-input w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@bookadmin.com"
                disabled={isLoading}
              />
            </div>

            <div>
              <label className="flex items-center mb-2 text-sm font-medium text-gray-700">
                <Lock className="w-4 h-4 mr-2" />
                Password
              </label>
              <input
                type="password"
                required
                className="neu-input w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                disabled={isLoading}
              />
            </div>
          </div>

          <button
            type="submit"
            className="neu-button w-full py-3 px-4 text-blue-600 font-semibold relative"
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="flex items-center justify-center">
                <span className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></span>
              </span>
            ) : (
              'Sign In'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}