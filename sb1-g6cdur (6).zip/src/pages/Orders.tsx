import React, { useState } from 'react';
import { ShoppingCart, PlusCircle } from 'lucide-react';
import { useOrders } from '../hooks/useOrders';
import OrderTable from '../components/OrderTable';
import OrderForm from '../components/OrderForm';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Order, OrderStatus, ORDER_STATUSES } from '../types/order';

export default function Orders() {
  const { 
    orders, loading, error, hasMore, addOrder, updateOrder, 
    deleteOrder, searchOrders, loadMore, filterByStatus, 
    updateOrderStatus, addOrderNote 
  } = useOrders();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingOrder, setDeletingOrder] = useState<Order | null>(null);

  const handleEdit = (order: Order) => {
    setEditingOrder(order);
    setShowEditForm(true);
  };

  const handleDelete = (order: Order) => {
    setDeletingOrder(order);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingOrder) {
      await deleteOrder(deletingOrder.id);
      setShowDeleteConfirm(false);
      setDeletingOrder(null);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShoppingCart className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Orders</h1>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          New Order
        </button>
      </div>

      <div className="flex gap-4 flex-col md:flex-row">
        <div className="flex-1">
          <SearchBar onSearch={searchOrders} />
        </div>
        <select
          onChange={(e) => filterByStatus(e.target.value as OrderStatus || null)}
          className="neu-input md:w-48"
        >
          <option value="">All Statuses</option>
          {Object.entries(ORDER_STATUSES).map(([status, { label }]) => (
            <option key={status} value={status}>
              {label}
            </option>
          ))}
        </select>
      </div>

      {loading && orders.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : orders.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No orders found.
        </div>
      ) : (
        <OrderTable
          orders={orders}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onUpdateStatus={updateOrderStatus}
          onAddNote={addOrderNote}
          loading={loading}
          hasMore={hasMore}
          onLoadMore={loadMore}
        />
      )}

      {/* Add Order Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Create New Order"
      >
        <OrderForm
          onSubmit={async (data) => {
            await addOrder(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Order Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingOrder(null);
        }}
        title="Edit Order"
      >
        <OrderForm
          initialData={editingOrder || undefined}
          onSubmit={async (data) => {
            if (editingOrder) {
              await updateOrder(editingOrder.id, data);
              setShowEditForm(false);
              setEditingOrder(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingOrder(null);
          }}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingOrder(null);
        }}
        title="Delete Order"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete order "{deletingOrder?.orderNumber}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingOrder(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}