import React, { useState } from 'react';
import { ShoppingBag, PlusCircle, Upload } from 'lucide-react';
import { useProducts } from '../hooks/useProducts';
import { useCategories } from '../hooks/useCategories';
import ProductCard from '../components/ProductCard';
import ProductForm from '../components/ProductForm';
import BulkProductUpload from '../components/BulkProductUpload';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { Product } from '../types/product';

export default function Products() {
  const { 
    products, loading, error, hasMore, addProduct, updateProduct, 
    deleteProduct, searchProducts, loadMore, filterByCategory, bulkAddProducts 
  } = useProducts();
  const { categories } = useCategories();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showBulkUpload, setShowBulkUpload] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingProduct, setDeletingProduct] = useState<Product | null>(null);

  // Get unique categories
  const uniqueCategories = Array.from(
    new Set(categories.map(cat => cat.name))
  ).map(name => categories.find(cat => cat.name === name)!);

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setShowEditForm(true);
  };

  const handleDelete = (product: Product) => {
    setDeletingProduct(product);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingProduct) {
      await deleteProduct(deletingProduct.id);
      setShowDeleteConfirm(false);
      setDeletingProduct(null);
    }
  };

  const handleBulkUpload = async (data: any[], onProgress: (progress: number) => void) => {
    try {
      await bulkAddProducts(data, onProgress);
      setShowBulkUpload(false);
    } catch (error) {
      console.error('Bulk upload error:', error);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ShoppingBag className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Products</h1>
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => setShowBulkUpload(true)}
            className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Bulk Upload
          </button>
          <button
            onClick={() => setShowAddForm(true)}
            className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            Add Product
          </button>
        </div>
      </div>

      <div className="flex gap-4 flex-col md:flex-row">
        <div className="flex-1">
          <SearchBar onSearch={searchProducts} />
        </div>
        <select
          onChange={(e) => filterByCategory(e.target.value || null)}
          className="neu-input md:w-48"
        >
          <option value="">All Categories</option>
          {uniqueCategories.map((category) => (
            <option key={category.id} value={category.id}>
              {category.name}
            </option>
          ))}
        </select>
      </div>

      {loading && products.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : products.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No products found.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onEdit={() => handleEdit(product)}
                onDelete={() => handleDelete(product)}
              />
            ))}
          </div>
          
          {hasMore && (
            <div className="mt-8 flex justify-center">
              <button
                onClick={loadMore}
                className="neu-button px-6 py-2 text-blue-600"
                disabled={loading}
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : (
                  'Load More'
                )}
              </button>
            </div>
          )}
        </>
      )}

      {/* Add Product Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Add New Product"
      >
        <ProductForm
          onSubmit={async (data) => {
            await addProduct(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit Product Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingProduct(null);
        }}
        title="Edit Product"
      >
        <ProductForm
          initialData={editingProduct || undefined}
          onSubmit={async (data) => {
            if (editingProduct) {
              await updateProduct(editingProduct.id, data);
              setShowEditForm(false);
              setEditingProduct(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingProduct(null);
          }}
        />
      </Modal>

      {/* Bulk Upload Modal */}
      <Modal
        isOpen={showBulkUpload}
        onClose={() => setShowBulkUpload(false)}
        title="Bulk Upload Products"
      >
        <BulkProductUpload
          onUpload={handleBulkUpload}
          onClose={() => setShowBulkUpload(false)}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingProduct(null);
        }}
        title="Delete Product"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete "{deletingProduct?.title}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingProduct(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}