import React, { useState } from 'react';
import { Users as UsersIcon, PlusCircle, Trash2, Edit2 } from 'lucide-react';
import { useUsers } from '../hooks/useUsers';
import UserTable from '../components/UserTable';
import UserForm from '../components/UserForm';
import SearchBar from '../components/SearchBar';
import Modal from '../components/Modal';
import { UserData } from '../types/user';

export default function Users() {
  const { 
    users, loading, error, hasMore, searchUsers, loadMore, 
    updateUserRole, addUser, updateUser, deleteUser 
  } = useUsers();
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [showEditForm, setShowEditForm] = useState(false);
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingUser, setDeletingUser] = useState<UserData | null>(null);

  const handleEdit = (user: UserData) => {
    setEditingUser(user);
    setShowEditForm(true);
  };

  const handleDelete = (user: UserData) => {
    setDeletingUser(user);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingUser) {
      await deleteUser(deletingUser.uid);
      setShowDeleteConfirm(false);
      setDeletingUser(null);
    }
  };

  if (error) {
    return (
      <div className="neu-flat p-6 text-red-600">
        {error}. Please try refreshing the page.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <UsersIcon className="w-8 h-8 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="neu-button px-4 py-2 text-blue-600 flex items-center gap-2"
        >
          <PlusCircle className="w-4 h-4" />
          Add User
        </button>
      </div>

      <div className="neu-flat p-4">
        <SearchBar onSearch={searchUsers} />
      </div>

      {loading && users.length === 0 ? (
        <div className="neu-flat p-6 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : users.length === 0 ? (
        <div className="neu-flat p-6 text-center text-gray-600">
          No users found.
        </div>
      ) : (
        <UserTable
          users={users}
          onSearch={searchUsers}
          loading={loading}
          hasMore={hasMore}
          onLoadMore={loadMore}
          onUpdateRole={updateUserRole}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      )}

      {/* Add User Modal */}
      <Modal
        isOpen={showAddForm}
        onClose={() => setShowAddForm(false)}
        title="Add New User"
      >
        <UserForm
          onSubmit={async (data) => {
            await addUser(data);
            setShowAddForm(false);
          }}
          onCancel={() => setShowAddForm(false)}
        />
      </Modal>

      {/* Edit User Modal */}
      <Modal
        isOpen={showEditForm}
        onClose={() => {
          setShowEditForm(false);
          setEditingUser(null);
        }}
        title="Edit User"
      >
        <UserForm
          initialData={editingUser || undefined}
          onSubmit={async (data) => {
            if (editingUser) {
              await updateUser(editingUser.uid, data);
              setShowEditForm(false);
              setEditingUser(null);
            }
          }}
          onCancel={() => {
            setShowEditForm(false);
            setEditingUser(null);
          }}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={showDeleteConfirm}
        onClose={() => {
          setShowDeleteConfirm(false);
          setDeletingUser(null);
        }}
        title="Delete User"
      >
        <div className="space-y-4">
          <p className="text-gray-600">
            Are you sure you want to delete the user "{deletingUser?.name}"? This action cannot be undone.
          </p>
          <div className="flex gap-4">
            <button
              onClick={confirmDelete}
              className="neu-button px-4 py-2 text-red-600 flex-1"
            >
              Delete
            </button>
            <button
              onClick={() => {
                setShowDeleteConfirm(false);
                setDeletingUser(null);
              }}
              className="neu-button px-4 py-2 text-gray-600"
            >
              Cancel
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}