import { Category } from './book';

export interface Blog {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  coverImage: string;
  author: {
    name: string;
    avatar: string;
  };
  category: Category | null;
  tags: string[];
  status: 'draft' | 'published';
  publishDate: Date | null;
  createdAt: Date;
  updatedAt: Date;
  readTime: number;
  featured: boolean;
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
  };
}

export interface BlogFormData {
  title: string;
  content: string;
  excerpt: string;
  coverImage: string;
  category: Category | null;
  tags: string[];
  status: 'draft' | 'published';
  publishDate: string | null;
  featured: boolean;
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
  };
}

export interface BlogCardProps {
  blog: Blog;
  onEdit: () => void;
  onDelete: () => void;
  onToggleStatus: () => void;
  onToggleFeatured: () => void;
}