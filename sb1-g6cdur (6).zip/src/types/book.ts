export interface Category {
  id: string;
  name: string;
}

export interface Book {
  id: string;
  bookName: string;
  authorName: string;
  longSummary: string;
  audioURL: string;
  pdfURL: string;
  coverImageURL: string;
  category: Category | null;
  price: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface BookFormData {
  bookName: string;
  authorName: string;
  longSummary: string;
  audioURL: string;
  pdfURL: string;
  coverImageURL: string;
  category: Category | null;
  price: number;
}

export interface SearchParams {
  query: string;
  page: number;
  limit: number;
}

export interface BulkUploadData {
  bookName: string;
  authorName: string;
  longSummary: string;
  audioURL: string;
  pdfURL: string;
  coverImageURL: string;
  categoryName?: string | null;
  price: number;
}