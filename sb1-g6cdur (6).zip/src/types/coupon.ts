import { Product } from './product';

export type DiscountType = 'fixed' | 'percentage';

export interface Coupon {
  id: string;
  code: string;
  description: string;
  discountType: DiscountType;
  discountValue: number;
  minPurchaseAmount: number;
  maxDiscountAmount: number;
  startDate: Date;
  endDate: Date | null;
  usageLimit: number;
  usageCount: number;
  isActive: boolean;
  applicableProducts: Product[] | null; // null means all products
  createdAt: Date;
  updatedAt: Date;
}

export interface CouponFormData {
  code: string;
  description: string;
  discountType: DiscountType;
  discountValue: number;
  minPurchaseAmount: number;
  maxDiscountAmount: number;
  startDate: string;
  endDate: string | null;
  usageLimit: number;
  isActive: boolean;
  applicableProducts: Product[] | null;
}

export interface CouponCardProps {
  coupon: Coupon;
  onEdit: () => void;
  onDelete: () => void;
  onToggleStatus: () => void;
}