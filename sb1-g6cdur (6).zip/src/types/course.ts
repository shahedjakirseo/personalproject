import { Timestamp } from 'firebase/firestore';

export interface Instructor {
  id: string;
  name: string;
  bio: string;
  photoURL: string;
  expertise: string[];
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  videoURL?: string;
  content?: string;
  isPreview: boolean;
  order: number;
}

export interface Chapter {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
  order: number;
}

export interface Course {
  id: string;
  title: string;
  slug: string;
  shortDescription: string;
  description: string;
  coverImage: string;
  previewVideo?: string;
  instructor: Instructor;
  chapters: Chapter[];
  price: number;
  status: 'draft' | 'published';
  level: 'beginner' | 'intermediate' | 'advanced';
  prerequisites: string[];
  tags: string[];
  totalDuration: number;
  totalLessons: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface CourseFormData {
  title: string;
  shortDescription: string;
  description: string;
  coverImage: string;
  previewVideo?: string;
  instructor: Omit<Instructor, 'id'>;
  price: number;
  status: 'draft' | 'published';
  level: 'beginner' | 'intermediate' | 'advanced';
  prerequisites: string[];
  tags: string[];
}