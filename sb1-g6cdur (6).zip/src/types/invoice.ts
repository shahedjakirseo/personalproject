import { Order } from './order';

export interface Invoice {
  id: string;
  orderNumber: string;
  order: Order;
  invoiceNumber: string;
  createdAt: Date;
  updatedAt: Date;
  status: 'paid' | 'unpaid' | 'cancelled';
  paymentMethod: string;
  paymentDate: Date | null;
  billingDetails: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    country: string;
    postcode: string;
  };
  items: {
    description: string;
    quantity: number;
    price: number;
    subtotal: number;
  }[];
  subtotal: number;
  discount: number;
  total: number;
  notes: string[];
}

export interface InvoiceFormData {
  status: 'paid' | 'unpaid' | 'cancelled';
  paymentMethod: string;
  paymentDate: string | null;
  notes: string[];
}