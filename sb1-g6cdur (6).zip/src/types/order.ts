import { Product } from './product';
import { Coupon } from './coupon';

export type OrderStatus = 
  | 'processing'
  | 'pending'
  | 'on-hold'
  | 'completed'
  | 'cancelled'
  | 'refunded';

export interface OrderItem {
  product: Product;
  quantity: number;
  price: number;
  subtotal: number;
}

export interface BillingDetails {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  country: string;
  postcode: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  status: OrderStatus;
  items: OrderItem[];
  billing: BillingDetails;
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  notes: string[];
  createdAt: Date;
  updatedAt: Date;
  paymentMethod: string;
  coupon?: {
    code: string;
    discount: number;
  };
}

export interface OrderFormData {
  status: OrderStatus;
  items: OrderItem[];
  billing: BillingDetails;
  discount: number;
  notes: string[];
  paymentMethod: string;
  coupon?: {
    code: string;
    discount: number;
  };
}

export interface CouponValidationResult {
  isValid: boolean;
  discount: number;
  error?: string;
}

export const ORDER_STATUSES: Record<OrderStatus, { label: string; color: string }> = {
  'processing': { label: 'Processing', color: 'text-blue-600 bg-blue-100' },
  'pending': { label: 'Pending Payment', color: 'text-yellow-600 bg-yellow-100' },
  'on-hold': { label: 'On Hold', color: 'text-orange-600 bg-orange-100' },
  'completed': { label: 'Completed', color: 'text-green-600 bg-green-100' },
  'cancelled': { label: 'Cancelled', color: 'text-red-600 bg-red-100' },
  'refunded': { label: 'Refunded', color: 'text-purple-600 bg-purple-100' }
};