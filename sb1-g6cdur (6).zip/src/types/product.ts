import { Category } from './book';

export interface Product {
  id: string;
  title: string;
  author: string;
  description: string;
  price: number;
  coverImage: string;
  pdfURL: string;
  isbn: string;
  pageCount: number;
  language: string;
  publisher: string;
  publishDate: string;
  edition: string;
  coverType: 'Hardcover' | 'Paperback';
  dimensions: {
    width: number;
    height: number;
    depth: number;
    unit: 'cm' | 'inch';
  };
  weight: {
    value: number;
    unit: 'kg' | 'g';
  };
  stock: number;
  category: Category | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface ProductFormData {
  title: string;
  author: string;
  description: string;
  price: number;
  coverImage: string;
  pdfURL: string;
  isbn: string;
  pageCount: number;
  language: string;
  publisher: string;
  publishDate: string;
  edition: string;
  coverType: 'Hardcover' | 'Paperback';
  dimensions: {
    width: number;
    height: number;
    depth: number;
    unit: 'cm' | 'inch';
  };
  weight: {
    value: number;
    unit: 'kg' | 'g';
  };
  stock: number;
  category: Category | null;
}

export const LANGUAGES = [
  'Bengali',
  'English',
  'Arabic',
  'Hindi',
  'Urdu'
] as const;

export const COVER_TYPES = ['Hardcover', 'Paperback'] as const;
export const DIMENSION_UNITS = ['cm', 'inch'] as const;
export const WEIGHT_UNITS = ['kg', 'g'] as const;