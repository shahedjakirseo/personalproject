export interface UserData {
  uid: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  photoURL: string;
  role: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserTableProps {
  users: UserData[];
  onSearch: (term: string) => void;
  loading: boolean;
  hasMore: boolean;
  onLoadMore: () => void;
  onUpdateRole: (uid: string, role: string) => void;
  onEdit: (user: UserData) => void;
  onDelete: (user: UserData) => void;
}