import { Category } from '../types/book';

export const getUniqueCategories = (categories: Category[]): Category[] => {
  return Array.from(
    new Map(categories.map(category => [category.id, category]))
  ).map(([_, category]) => category);
};

export const sortCategories = (categories: Category[]): Category[] => {
  return [...categories].sort((a, b) => a.name.localeCompare(b.name));
};